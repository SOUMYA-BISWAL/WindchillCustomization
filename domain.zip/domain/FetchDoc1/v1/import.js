/**
 * Invokes InfoEngine task with the given parameters and returns collection of PTC.IE.Group entities.
 * 
 * @param data Data for processing action request
 * @param params Parameters required to invoke the InfoEngine task
 * @returns Collection of PTC.ECM.ChangeIssue entities
 */
function action_fetchDocument(data, params) {
	
	// Import necessary Classes
	var System = Java.type('java.lang.System');
	var WTContainerRef = Java.type('wt.inf.container.WTContainerRef');
	var WTContainerHelper = Java.type('wt.inf.container.WTContainerHelper');
	var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
	var ActionResult = Java.type("com.ptc.odata.core.entity.processor.ActionResult");
	var WTReference = Java.type('wt.fc.WTReference');
	var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var File = Java.type('java.io.File');
	var ApplicationData = Java.type('wt.content.ApplicationData');
	var ContentRoleType = Java.type('wt.content.ContentRoleType');
	var Transaction = Java.type('wt.pom.Transaction');
	var ContentServerHelper = Java.type('wt.content.ContentServerHelper');
	var WTDocument = Java.type('wt.doc.WTDocument');
	var URL = Java.type('java.net.URL');
	var HttpURLConnection = Java.type('java.net.HttpURLConnection');
	var String = Java.type('java.lang.String');
	var StringBuilder = Java.type('java.lang.StringBuilder');
	var InputStreamReader = Java.type('java.io.InputStreamReader');
	var BufferedReader = Java.type('java.io.BufferedReader');
	var JSONObject = Java.type('org.json.JSONObject');
	var FileWriter = Java.type('java.io.FileWriter');
	var QuerySpec = Java.type('wt.query.QuerySpec');
	var QueryResult = Java.type('wt.fc.QueryResult');
	var WhereExpression = Java.type('wt.query.WhereExpression');
	var SearchCondition = Java.type('wt.query.SearchCondition');
	var StatementSpec = Java.type('wt.pds.StatementSpec');
	var VersionControlHelper = Java.type('wt.vc.VersionControlHelper');
	var LifeCycleState = Java.type('wt.lifecycle.LifeCycleState');
	var RevisionControlled = Java.type('wt.enterprise.RevisionControlled');
	var WorkInProgressHelper = Java.type('wt.vc.wip.WorkInProgressHelper');
	var Base64 = Java.type('java.util.Base64');
	
	var docNumber="0123456";
	System.out.println(docNumber);
	var document = new WTDocument();
	var searchCondition= new SearchCondition(WTDocument.class, "master>number", SearchCondition.EQUAL, docNumber, true)
	var querySpec = new QuerySpec(WTDocument.class);
	querySpec.appendWhere((WhereExpression)searchCondition, new Array(0));				
	System.out.println(querySpec);
	var queryResult = PersistenceHelper.manager.find((StatementSpec)Query);
	var name = params.get('name').getValue();
	var description = params.get('description').getValue();
	var organisation = params.get('organisation').getValue();
	var product = params.get('product').getValue();
	var contentURL = params.get('ContentURL').getValue();
	System.out.println("PostMan Inputs : \nname : "+name+"description : "+description+"organisation : "+organisation+"product : "+product+" contentURL => "+contentURL);
		
	//If Document is exist
	if(queryResult.size()>0) {
		document = (WTDocument)queryResult.nextElement();
		var latDoc = (WTDocument)VersionControlHelper.service.getLatestIteration(document,true);
		var lifecycleState= latDoc.getState();
		System.out.println("Hi State is  "+ lifecycleState.getClass().getName());
		
		
			/*if(lifecycleState.toString().equals("INWORK")) {
				document = (WTDocument) WorkInProgressHelper.service.checkout(document, WorkInProgressHelper.service.getCheckoutFolder(), "").getWorkingCopy();
				
				//After checked out update primary content
					var contentURL = params.get('ContentURL').getValue();
					var fileName=contentURL.substring(contentURL.lastIndexOf('/')+1,contentURL.length());
					System.out.println("fileName => "+fileName);
					var url = new URL(contentURL);
					var urlConnection = url.openConnection();
					var userName = "Administrator";
					var password ="thingworx";
					var userpass = userName + ":" + password;
					var basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
					urlConnection.setRequestProperty ("Authorization", basicAuth);
					var inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
					var bufferedReader  = new BufferedReader(inputStreamReader);
					var responseStrBuilder = new StringBuilder();
					var line=null;
					while ((line = bufferedReader.readLine()) != null) {
						responseStrBuilder.append(line);
					}
					var jsonObject = new JSONObject(responseStrBuilder.toString());
					System.out.println("JSON OBject => "+jsonObject);
					file = new File("D:\\"+fileName);
					var writer = new FileWriter(file);
					writer.write(jsonObject.toJSONString());
					writer.close();
					var docAD = ApplicationData.newApplicationData(document);
					docAD.setFileName(file.getName());
					docAD.setUploadedFromPath("D:\\"+fileName);
					docAD.setRole(ContentRoleType.PRIMARY);
					var inputstream = new java.io.FileInputStream(file);
					ContentServerHelper.service.updateContent(document, docAD,inputstream);
					transaction.commit();
					transaction=null;
					inputstream.close();
				document = (WTDocument) WorkInProgressHelper.service.checkin(document, "its Updated");
				
				//If the Document state is RELEASED 
			}else if(lifecycleState.equals("RELEASED")) {
				var localRevisionControlled=null;
				localRevisionControlled=(RevisionControlled) VersionControlHelper.service.newVersion(document);
				localRevisionControlled=(RevisionControlled) PersistenceHelper.manager.save(localRevisionControlled);
				var latDoc1 = (WTDocument)VersionControlHelper.service.getLatestIteration(document,true);
				
				//After Revision update primary content
				var contentURL = params.get('ContentURL').getValue();
					var fileName=contentURL.substring(contentURL.lastIndexOf('/')+1,contentURL.length());
					System.out.println("fileName => "+fileName);
					var url = new URL(contentURL);
					var urlConnection = url.openConnection();
					var userName = "Administrator";
					var password ="thingworx";
					var userpass = userName + ":" + password;
					var basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
					urlConnection.setRequestProperty ("Authorization", basicAuth);
					var inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
					var bufferedReader  = new BufferedReader(inputStreamReader);
					var responseStrBuilder = new StringBuilder();
					var line=null;
					while ((line = bufferedReader.readLine()) != null) {
						responseStrBuilder.append(line);
					}
					var jsonObject = new JSONObject(responseStrBuilder.toString());
					System.out.println("JSON OBject => "+jsonObject);
					file = new File("D:\\"+fileName);
					var writer = new FileWriter(file);
					writer.write(jsonObject.toJSONString());
					writer.close();
					var docAD = ApplicationData.newApplicationData(latDoc1);
					docAD.setFileName(file.getName());
					docAD.setUploadedFromPath("D:\\"+fileName);
					docAD.setRole(ContentRoleType.PRIMARY);
					var inputstream = new java.io.FileInputStream(file);
					ContentServerHelper.service.updateContent(latDoc1, docAD,inputstream);
					transaction.commit();
					transaction=null;
					inputstream.close();*/
				
	}else{	
	// If Document is not exist create new Document

	
	var containerPath = "/wt.inf.container.OrgContainer="+organisation+"/wt.pdmlink.PDMLinkProduct="+product;
	var containerRef = WTContainerHelper.service.getByPath(containerPath);
	var transaction = new Transaction();
	var result = new ActionResult();
	
	// New WTDOCUMENT Creation and Setting Attributes
	var doc = WTDocument.newWTDocument();
	doc.setName(name);
	doc.setContainerReference(containerRef);
	
	if(description!=null){
			doc.setDescription(description);
	}
	
	// Database Commit
	doc = PersistenceHelper.manager.store(doc);
	
	//Database Transaction
	transaction.start();
	
	var fileName=contentURL.substring(contentURL.lastIndexOf('/')+1,contentURL.length());
	System.out.println("fileName => "+fileName);
	
	var url = new URL(contentURL);
	var urlConnection = url.openConnection();
	var userName = "Administrator";
	var password ="thingworx";
	var userpass = userName + ":" + password;
	var basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
	urlConnection.setRequestProperty ("Authorization", basicAuth);
	var inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
	
	var bufferedReader  = new BufferedReader(inputStreamReader);
	var responseStrBuilder = new StringBuilder();
	var line=null;
	while ((line = bufferedReader.readLine()) != null) {
		responseStrBuilder.append(line);
	}
	var jsonObject = new JSONObject(responseStrBuilder.toString());
	System.out.println("JSON OBject => "+jsonObject);
	file = new File("D:\\"+fileName);
	var writer = new FileWriter(file);
	writer.write(jsonObject.toJSONString());
	writer.close();

	var docAD = ApplicationData.newApplicationData(doc);
	docAD.setFileName(file.getName());
	docAD.setUploadedFromPath("D:\\"+fileName);
	docAD.setRole(ContentRoleType.PRIMARY);
	var inputstream = new java.io.FileInputStream(file);
	ContentServerHelper.service.updateContent(doc, docAD,inputstream);
	transaction.commit();
	transaction=null;
	inputstream.close();
	
	// Returning new created ChangeIssue as action result
	doc = PersistenceHelper.manager.refresh(doc);
    var documentEntity = data.getProcessor().toEntity(doc, data);
    result.setReturnedObject(documentEntity);
    return result;
	}
}