function action_uploadStage1Action() {
    // call method in ContentHolderEntityDelegate
    //var ContentHolderEntityDelegate = Java.type("com.ptc.odata.windchill.entity.service.ContentHolderEntityDelegate");
	var System = Java.type('java.lang.System');
	System.out.println("SOUMYA_RANJAN_BISWAL");
	var result="soumyq";
	return result;
    //return ContentHolderEntityDelegate.uploadStage1Action("document", data, params);
}
