function getRelatedEntityCollection(navProcessorData) {
var HashMap = Java.type('java.util.HashMap');
var ArrayList = Java.type('java.util.ArrayList');
var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
var ChangeHelper2 = Java.type('wt.change2.ChangeHelper2');
var targetName = navProcessorData.getTargetSetName();
var map = new HashMap();
var sourcePRs = new WTArrayList(navProcessorData.getSourceObjects());
if("ReportedAgainst".equals(targetName)) {
for(var i = 0; i < sourcePRs.size(); i++) {
var sourcePR = sourcePRs.getPersistable(i);
var reportedAgainstItems = ChangeHelper2.service.getChangeables(sourcePR, true);
var list = new ArrayList();
while(reportedAgainstItems.hasMoreElements()) {
list.add(reportedAgainstItems.nextElement());
}
map.put(sourcePR, list);
}
}
return map;
}