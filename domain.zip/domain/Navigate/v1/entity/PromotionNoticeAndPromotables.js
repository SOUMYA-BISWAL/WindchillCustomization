function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var part =Java.type('wt.part.WTPart');
	var mHelper = Java.type('wt.maturity.MaturityHelper');
	var ObjectType= Java.type('java.lang.String');
	var ObjectNumber= Java.type('java.lang.String');
	var ObjectName= Java.type('java.lang.String');
	var promotionNoticeNumber= Java.type('java.lang.String');
	var targetState= Java.type('java.lang.String');
	var promotionComments =Java.type('java.lang.String');
	var qrResult = Java.type('wt.fc.QueryResult');
	var objectVersion =Java.type('java.lang.String');
	var contextName =Java.type('java.lang.String');
	var maturityHelper =Java.type('wt.maturity.MaturityHelper');
	var doc =Java.type('wt.doc.WTDocument');
	var epmdoc = Java.type('wt.epm.EPMDocument');
	var promotionTarget = Java.type('wt.maturity.PromotionTarget');
	var targetObjects = Java.type('wt.fc.collections.WTCollection');
	var wtcollection1 = Java.type('wt.fc.collections.WTCollection');
	var promotionTarget= Java.type('wt.maturity.PromotionTarget');
	var promotableObj= Java.type('wt.fc.Persistable');
    var wtArrayList = Java.type('wt.fc.collections.WTArrayList');
	var ArrayList = Java.type('java.util.ArrayList');
	var objectRef =Java.type('wt.fc.ObjectReference');
    var objectEntityMap = new HashMap();
    var persistableObjects = OidHelper.getWTCollection(objects);
	var wtArray;
	var persistable=Java.type('wt.fc.Persistable');
	var promotionNoticeObj=Java.type('wt.maturity.PromotionNotice');
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
	var typeUtilityServicehelper=Java.type('wt.type.TypedUtilityServiceHelper');
	  
	  	for each(var localObject in persistableObjects.persistableCollection()) 
		{
			wtArray = new wtArrayList();
			wtArray.add(localObject);
			wtcollection1 = null;
		}
		wtcollection1= maturityHelper.service.getPromotionNotices(wtArray);
					
		if(!wtcollection1.isEmpty()){
			for each (var promotionObject in wtcollection1)
				{
					objectRef=promotionObject;
					persistable=objectRef.getObject();
			  if(persistable.getClass().getName().equalsIgnoreCase("wt.maturity.PromotionNotice")){
					promotionNoticeObj=persistable;               
             }
		 }
	 }	 	
	qrResult = mHelper.service.getPromotionTargets(promotionNoticeObj, false);
		
			for each(var e in list) {
				var entityId = EntityIDUtils.getInstance().getEntityId(e);
				var nmId = NmOid.newNmOid(entityId);
				var objId = nmId.getOidObject();
				var promotionRequest = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
			
				if(qrResult.hasMoreElements()){
				promotionTarget = qrResult.nextElement();
				promotableObj = promotionTarget.getRoleBObject();
			
				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.doc.WTDocument")) {
				doc =  promotableObj;
				ObjectType =typeUtilityServicehelper.service.getExternalTypeIdentifier(doc);
				ObjectNumber =doc.getNumber();
				ObjectName =doc.getName();
				objectVersion =doc.getIterationDisplayIdentifier();
				targetState=promotionTarget.getCreateState().toString();
				contextName=doc.getContainerName();
					
				 e.addProperty(new Property('Edm.String', 'IterationInfo', ValueType.PRIMITIVE, objectVersion));
				 e.addProperty(new Property('Edm.String', 'ObjType', ValueType.PRIMITIVE, ObjectType));
				 e.addProperty(new Property('Edm.String', 'contextName', ValueType.PRIMITIVE, contextName));
			     e.addProperty(new Property('Edm.String', 'TargetState', ValueType.PRIMITIVE, targetState));
				 e.addProperty(new Property('Edm.String', 'PromotionComments', ValueType.PRIMITIVE, promotionTarget.getDescription() != null ? promotionTarget.getDescription() : ""));
				}	
				
				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.part.WTPart")) {
				part =  promotableObj;
				ObjectType =typeUtilityServicehelper.service.getExternalTypeIdentifier(part);
				ObjectNumber =part.getNumber();
				ObjectName =part.getName();
				objectVersion =part.getIterationDisplayIdentifier();
				contextName=part.getContainerName();
				targetState=promotionTarget.getCreateState().toString();
				
				e.addProperty(new Property('Edm.String', 'IterationInfo', ValueType.PRIMITIVE, objectVersion));
				e.addProperty(new Property('Edm.String', 'ObjType', ValueType.PRIMITIVE, ObjectType));
				e.addProperty(new Property('Edm.String', 'contextName', ValueType.PRIMITIVE, contextName));
				e.addProperty(new Property('Edm.String', 'TargetState', ValueType.PRIMITIVE, targetState));
				e.addProperty(new Property('Edm.String', 'PromotionComments', ValueType.PRIMITIVE, promotionTarget.getDescription() != null ? promotionTarget.getDescription() : ""));
				}
				
				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.epm.EPMDocument")) {
				epmdoc =  promotableObj;
				ObjectType =typeUtilityServicehelper.service.getExternalTypeIdentifier(epmdoc);
				ObjectNumber =epmdoc.getNumber();
				ObjectName =epmdoc.getName();
				objectVersion =epmdoc.getIterationDisplayIdentifier();
				contextName=epmdoc.getContainerName();
				targetState=promotionTarget.getCreateState().toString();
					
				e.addProperty(new Property('Edm.String', 'IterationInfo', ValueType.PRIMITIVE, objectVersion));
				e.addProperty(new Property('Edm.String', 'ObjType', ValueType.PRIMITIVE, ObjectType));
				e.addProperty(new Property('Edm.String', 'contextName', ValueType.PRIMITIVE, contextName));
				e.addProperty(new Property('Edm.String', 'TargetState', ValueType.PRIMITIVE, targetState));
				e.addProperty(new Property('Edm.String', 'PromotionComments', ValueType.PRIMITIVE, promotionTarget.getDescription() != null ? promotionTarget.getDescription() : ""));
				}
		}
						
			objectEntityMap.put(promotionRequest, e);
    }
    return objectEntityMap;
}


