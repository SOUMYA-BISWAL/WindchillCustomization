function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
	var PRState = Java.type('java.lang.String');
	var prDescription = Java.type('java.lang.String');
	var prNeedBy = Java.type('java.lang.String');
	var prTTName = Java.type('java.lang.String');
	var PRContainer = Java.type('java.lang.String');
	var folderPath = Java.type('java.lang.String');
	var createdBy = Java.type('java.lang.String');
	var lastModified = Java.type('java.lang.String');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');

    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
    var persistableObjects = OidHelper.getWTCollection(objects);
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
	
	
    for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
        var promotionRequest = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
		PRState= promotionRequest.getMaturityState().toString();
		PRContainer= promotionRequest.getContainerName();
		prDescription=	promotionRequest.getDescription();
		prTTName =promotionRequest.getTeamTemplateName();
		folderPath = promotionRequest.getLocation();
		createdBy =promotionRequest.getCreator().getName();
		prNeedBy = promotionRequest.getNeedBy();
	lastModified=	promotionRequest.getModifyTimestamp();
     	 e.addProperty(new Property('Edm.String', 'PromotionState', ValueType.PRIMITIVE, PRState));
	 e.addProperty(new Property('Edm.String', 'Context', ValueType.PRIMITIVE, PRContainer));
	 e.addProperty(new Property('Edm.String', 'PRDescription', ValueType.PRIMITIVE, prDescription));
	 e.addProperty(new Property('Edm.String', 'NeedBy', ValueType.PRIMITIVE, prNeedBy));
	 
	 e.addProperty(new Property('Edm.String', 'TeamTemplate', ValueType.PRIMITIVE, prTTName));
	 e.addProperty(new Property('Edm.String', 'Folder', ValueType.PRIMITIVE, folderPath));
	 e.addProperty(new Property('Edm.String', 'CreatedBy', ValueType.PRIMITIVE, createdBy));
	 e.addProperty(new Property('Edm.String', 'LastModified', ValueType.PRIMITIVE, lastModified));
        objectEntityMap.put(promotionRequest, e);
    }
    return objectEntityMap;
}

function getRelatedEntityCollection(navProcessorData) {
    
    var HashMap = Java.type('java.util.HashMap');
    var ArrayList = Java.type('java.util.ArrayList');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	
    var ChangeHelper2 = Java.type('wt.fc.WTObject');
	var maturityHelper =Java.type('wt.maturity.MaturityHelper');
    var targetName = navProcessorData.getTargetSetName();
	
    var map = new HashMap();
    var sourceChangeRequests = new WTArrayList(navProcessorData.getSourceObjects());
	
	var queryResult= Java.type('wt.fc.QueryResult');
	var promotionTarget = Java.type('wt.maturity.PromotionTarget');
	var promotableObj =Java.type('wt.fc.Persistable');
	  var part =Java.type('wt.part.WTPart');
	   var ObjectType= Java.type('java.lang.String');
	  var ObjectNumber= Java.type('java.lang.String');
	  var ObjectName= Java.type('java.lang.String');
	  var targetState= Java.type('java.lang.String');
	  var promotionComments =Java.type('java.lang.String');
	  var objectVersion =Java.type('java.lang.String');
	  var contextName =Java.type('java.lang.String');
	  var doc =Java.type('wt.doc.WTDocument');
	  var epmdoc = Java.type('wt.epm.EPMDocument');
    if("Promotables".equals(targetName)) {
        for(var i = 0; i < sourceChangeRequests.size(); i++) {
            var sourceChangeRequest = sourceChangeRequests.getPersistable(i);
			
            var changeableItems =maturityHelper.service.getPromotionTargets(sourceChangeRequest, true);
			queryResult = maturityHelper.service.getPromotionTargets(sourceChangeRequest, false);
			
			while (queryResult.hasMoreElements()){
				 promotionTarget = queryResult.nextElement();
				promotableObj = promotionTarget.getRoleBObject();
				
				
				
				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.part.WTPart")) {
					part =  promotableObj;
					ObjectType =part.getType();
					ObjectNumber =part.getNumber()
					ObjectName =part.getName();
					targetState =promotionTarget.getCreateState().toString();
					promotionComments =promotionTarget.getDescription();
					objectVersion =part.getIterationDisplayIdentifier();
					contextName=part.getContainerName();
					
				}
				
				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.doc.WTDocument")) {
					doc =  promotableObj;
					ObjectType =doc.getType();
					ObjectNumber =doc.getNumber()
					ObjectName =doc.getName();
					targetState =promotionTarget.getCreateState().toString();
					promotionComments =promotionTarget.getDescription();
					objectVersion =doc.getIterationDisplayIdentifier();
					contextName=doc.getContainerName();
					
				}	

				if(promotableObj.getClass().getName().equalsIgnoreCase("wt.epm.EPMDocument")) {
					epmdoc =  promotableObj;
					ObjectType =epmdoc.getType();
					ObjectNumber =epmdoc.getNumber()
					ObjectName =epmdoc.getName();
					targetState =promotionTarget.getCreateState().toString();
					promotionComments =promotionTarget.getDescription();
					objectVersion =epmdoc.getIterationDisplayIdentifier();
					contextName=epmdoc.getContainerName();
					
				}			
				
			}
            var list = new ArrayList();
            while(changeableItems.hasMoreElements()) {
                list.add(changeableItems.nextElement());

            }
            map.put(sourceChangeRequest, list);
        }
    }

    return map;
}
