function readEntitySetData(processorData) {
    var Collections = Java.type('java.util.Collections');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');
	var string =Java.type('java.lang.String');
	var currentUser = SessionHelper.getPrincipal();
	var ArrayList = Java.type('java.util.ArrayList');
	var list = new ArrayList();
    var itemList = Collections.list(WorkflowHelper.service.getWorkItems(currentUser));
	for(var i = 0; i < itemList.size(); i++) {
		
		var wi = Java.type('wt.workflow.work.WorkItem');
		wi=itemList[i];
		string=wi.getPrimaryBusinessObject().getObject().getType();
		if(string.contains("Promotion Request"))
		{
			list.add(wi);
		
		}
	}
    return list;
}


function toEntities(objects, processorData) {

    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var ComplexValue = Java.type('org.apache.olingo.commons.api.data.ComplexValue');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ArrayList = Java.type('java.util.ArrayList');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var owner= Java.type('wt.ownership.Ownership');
	var contName =Java.type('java.lang.String');
	var taskName =Java.type('java.lang.String');
	var prDescription =Java.type('java.lang.String');
	var taskTemp =Java.type('java.lang.String');
	var wfProcessCreator= Java.type('java.lang.String');
	var wfProcessCreatedOn = Java.type('java.lang.String');
	var routingEvents = Java.type('java.lang.String');
	var maturitystate =Java.type('java.lang.String');//str
	var temp = Java.type('java.lang.String');
	var workitemstatus = Java.type('java.lang.String');//stat12
	var prState = Java.type('java.lang.String');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var Class = Java.type('java.lang.Class');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
	var promotionNotice = Java.type('wt.maturity.PromotionNotice');//pr1
	var prTTName= Java.type('java.lang.String');
	var priority= Java.type('java.lang.Long');
	var prNum =Java.type('java.lang.String');
	var folderPath = Java.type('java.lang.String');
	var comments =Java.type('java.lang.String');
	var taskComments =Java.type('java.lang.String');
	var createdBy = Java.type('java.lang.String');
	var prName =Java.type('java.lang.String');
	var prNeedBy =Java.type('java.lang.String');
	var sub =Java.type('java.lang.String');
	var role = Java.type('java.lang.String');
	var processname =Java.type('java.lang.String');
	var queryResult= Java.type('wt.fc.QueryResult');
	var wtContained = Java.type('wt.inf.container.WTContained');
	var wfEngineHelper = Java.type('wt.workflow.engine.WfEngineHelper');
	var wfProcess = Java.type('wt.workflow.engine.WfProcess');
	var currentUser = SessionHelper.getPrincipal();
    var currentUserReference = WTPrincipalReference.newWTPrincipalReference(currentUser);
    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
	var taskObject =Java.type('ext.util.rest.getUserWorkItem');
	var PNOID= Java.type('java.lang.String');
	var taskComment = Java.type('java.lang.String');
    var persistableObjects = OidHelper.getWTCollection(objects);
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
	var tasklist = new ArrayList();
	var wfprocesstemplate = Java.type('wt.workflow.definer.WfProcessTemplate');
	    
   for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
		var persistable = Java.type('wt.fc.Persistable');
        var workItem = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
		
		persistable=workItem.getPrimaryBusinessObject().getObject();
		promotionNotice=persistable;
		wtContained =promotionNotice;
		queryResult = wfEngineHelper.service.getAssociatedProcesses
							(promotionNotice, null, wtContained.getContainerReference());
		
		PNOID = "OR:"+persistable;
			while(queryResult.hasMoreElements())
			{
		
					wfProcess = queryResult.nextElement();
					taskTemp= wfProcess.getIdentity();
					wfprocesstemplate =wfProcess.getTemplate().getObject();
					wfProcessCreator = wfProcess.getCreator().getName();
					wfProcessCreatedOn= wfProcess.getCreateTimestamp();
					processname=wfprocesstemplate.getName();
	

			}		
		maturitystate=promotionNotice.getMaturityState().toString();
		prNum= promotionNotice.getNumber();
		prName= promotionNotice.getName();
		contName= promotionNotice.getContainerName();
	    prDescription=	promotionNotice.getDescription();
		prNeedBy = promotionNotice.getNeedBy();
		prTTName =promotionNotice.getTeamTemplateName();
		folderPath = promotionNotice.getLocation();
		createdBy =promotionNotice.getCreator().getName();
		owner = workItem.getOwnership();
		var lastMod= promotionNotice.getModifyTimestamp();		
		workitemstatus=workItem.getStatus().toString();
		role=workItem.getRole().toString();
		var createTimestamp =workItem.getCreateTimestamp().toString();//ct1
		sub="Promotion Request -" + prNum +','+prName;
		temp =workItem.toString();
		var tokenizer = Java.type('java.util.StringTokenizer');
		var taskNumber = Java.type('java.lang.String');

	    taskComment=taskObject.getMyComments(workItem);

		tokenizer = new tokenizer(temp, ":");
				     while (tokenizer.hasMoreTokens()){
						
				    tasklist.add(tokenizer.nextToken());
					
				     }
		 taskNumber= tasklist.get(1);
        var assignments = PersistenceHelper.manager.navigate(workItem, 'theWfAssignment', Class.forName('wt.workflow.work.WorkItemLink'), true);
        var wfAssignment = assignments.nextElement();
        var assignedTo = owner.getOwner().getName();
        var activities = PersistenceHelper.manager.navigate(wfAssignment, 'activity', Class.forName('wt.workflow.work.ActivityAssignmentLink'), true);
        var activity = activities.nextElement();
        var deadline = activity.getDeadline();
        var name = activity.getName();
        var instructions = activity.getInstructions();
		routingEvents = activity.getUserEventList();
		priority= activity.getPriority();

		taskName= taskTemp+'- '+ name; 

        e.addProperty(new Property('Edm.String', 'Task', ValueType.PRIMITIVE, taskName));
		e.addProperty(new Property('Edm.String', 'Name', ValueType.PRIMITIVE, name));
        e.addProperty(new Property('Edm.String', 'Instructions', ValueType.PRIMITIVE, instructions));
		e.addProperty(new Property('Edm.String', 'Process', ValueType.PRIMITIVE, taskTemp));
		e.addProperty(new Property('Edm.String', 'ProcessInitiator', ValueType.PRIMITIVE, wfProcessCreator));
		e.addProperty(new Property('Edm.String', 'ProcessInitiatedOn', ValueType.PRIMITIVE, wfProcessCreatedOn));
        e.addProperty(new Property('Edm.String', 'Assignee', ValueType.PRIMITIVE, assignedTo));
        e.addProperty(new Property('Edm.DateTimeOffset', 'Deadline', ValueType.PRIMITIVE, deadline));
		e.addProperty(new Property('Edm.String', 'PromotionState', ValueType.PRIMITIVE, maturitystate));
		e.addProperty(new Property('Edm.String', 'PromotionNoticeNumber', ValueType.PRIMITIVE, prNum));
		e.addProperty(new Property('Edm.String', 'Context', ValueType.PRIMITIVE, contName));
		e.addProperty(new Property('Edm.String', 'Subject', ValueType.PRIMITIVE, sub));
		e.addProperty(new Property('Edm.String', 'TaskNumber', ValueType.PRIMITIVE, taskNumber));
		e.addProperty(new Property('Edm.String', 'Status', ValueType.PRIMITIVE, workitemstatus));
		e.addProperty(new Property('Edm.String', 'Role', ValueType.PRIMITIVE, role));
		e.addProperty(new Property('Edm.String', 'RoutingOptions', ValueType.PRIMITIVE, routingEvents));
		e.addProperty(new Property('Edm.String', 'PromotionNoticeName', ValueType.PRIMITIVE, prName));
		e.addProperty(new Property('Edm.String', 'Assigned', ValueType.PRIMITIVE, createTimestamp));
		e.addProperty(new Property('Edm.String', 'PRDescription', ValueType.PRIMITIVE, prDescription));
		e.addProperty(new Property('Edm.String', 'NeedBy', ValueType.PRIMITIVE, prNeedBy));
		e.addProperty(new Property('Edm.String', 'TeamTemplate', ValueType.PRIMITIVE, prTTName));
		e.addProperty(new Property('Edm.String', 'Folder', ValueType.PRIMITIVE, folderPath));
		e.addProperty(new Property('Edm.String', 'CreatedBy', ValueType.PRIMITIVE, createdBy));
		e.addProperty(new Property('Edm.String', 'PromotionProcess', ValueType.PRIMITIVE, processname));
		e.addProperty(new Property('Edm.String', 'Comments', ValueType.PRIMITIVE, taskComment));
		e.addProperty(new Property('Edm.String', 'Priority', ValueType.PRIMITIVE, priority ==1? "Highest":""));
		e.addProperty(new Property('Edm.String', 'LastModified', ValueType.PRIMITIVE, lastMod));
		e.addProperty(new Property('Edm.String', 'PromotionNoticeOID', ValueType.PRIMITIVE, PNOID));
		
				
			
        objectEntityMap.put(workItem, e);
		tasklist.clear();
    }

    return objectEntityMap;
}

