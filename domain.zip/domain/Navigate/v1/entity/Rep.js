function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
	var HashMap = Java.type('java.util.HashMap');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	var objectEntityMap = new HashMap();
	var Enumeration= Java.type("java.util.Enumeration");
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var sysOut=Java.type('java.lang.System');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	var RfObject=Java.type('wt.fc.WTReference');
	var arrayList = Java.type('java.util.ArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTMarkUp=Java.type('wt.viewmarkup.WTMarkUp');
	var Viewable=Java.type('wt.viewmarkup.Viewable');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
	var WTException=Java.type('wt.util.WTException');
	var Representation=Java.type('wt.representation.Representation');
	var QueryResult=Java.type('wt.fc.QueryResult');
	var ContentHelper=Java.type('wt.content.ContentHelper');
	var repList=new arrayList();
	
	
	sysOut.out.println("Entities Method objects class  :- "+objects.getClass());
	sysOut.out.println("Entities Method objects  :- "+objects);
	sysOut.out.println("Processor Data Class :- "+processorData.getClass());
	
	
	var persistableObjects = OidHelper.getWTCollection(objects);
	
	sysOut.out.println("Entities Method persistableObjects  :- "+persistableObjects);
	
	var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
	var list = entityCollection.getEntities();
	sysOut.out.println("Entities Method List  :- "+list);
	var i=0;
	for each(var e in list) { // Entities Loop
	i++;
		if(e!=null){
			var entityId = EntityIDUtils.getInstance().getEntityId(e);
			sysOut.out.println("########## Entity Type Class #############"+e.getClass());
			
			var nmId = NmOid.newNmOid(entityId);
			var objId = nmId.getOidObject();
			var rfObjectRep = new refFact().getReference(entityId);
			sysOut.out.println("########"+"RefObject is "+rfObjectRep.getObject());
			
			//Creating Local Representation
			var localRep=null;
				
			if (rfObjectRep.getObject() instanceof Representation)
			{
				localRep= rfObjectRep.getObject();
				sysOut.out.println("Derived Image Identity is "+localRep.getName());
		
			}
				
				//var repProp=rep;
				//rep = ContentHelper.service.getContents(rep);
				var repName=localRep.getName();
				var repDescription=localRep.getDescription();
				var repCreated_Time= localRep.getPersistInfo().getCreateStamp();
				var repModified_time= localRep.getPersistInfo().getModifyStamp();
				
				//var repContents = ContentHelper.service.getContents(localRep);
				var thumbnailURL=null;
				if(ContentHelper.service.getThumbnail(localRep)!=null) {
					thumbnailURL = ContentHelper.service.getDownloadURL(localRep,ContentHelper.service.getThumbnail(localRep));
				}
					
				
				
				
				sysOut.out.print("########## Start Representation#############\n"+localRep.getName());
				sysOut.out.print(">>>> "+localRep.getName());
				sysOut.out.println("Test >>>> "+localRep.getDescription()+" "+localRep.isDefaultRepresentation()+" "+localRep.getRepresentable().getIdentity());
				sysOut.out.println("Modify date:"+repModified_time);
				sysOut.out.println("created time:"+repCreated_Time);
	//sysOut.out.println("Thumbnail URl: "+ContentHelper.service.getDownloadURL(localRep,ContentHelper.service.getThumbnail(localRep)));
				sysOut.out.println("##########  END Representation #############");
				
				/*
				var markUps  = ViewMarkUpHelper.service.getMarkUps(localRep);
				var markUpMap = new HashMap();
				// Creating sub entities for annotations
				
				var markUpsList=new arrayList();
				
				while(markUps.hasMoreElements()){
				
				markUpsList.add(markUps.nextElement());
			
				}
				
				var persistableMarkUpObjects = OidHelper.getWTCollection(markUpsList);
				sysOut.out.println(">>>>>>>>>>>>>>>>>>>>persistableMarkUpObjects  :- " + persistableMarkUpObjects);
				
				var entityMarkUpCollection = EntityAttributeProcessor.newInstance().createEntities(persistableMarkUpObjects.persistableCollection(), processorData);
				sysOut.out.println(">>>>>>>>>>>>>>>>>>>>entityMarkUpCollection  :- " + entityMarkUpCollection);
				
				var markUpEntitylist = entityMarkUpCollection.getEntities();
				
				sysOut.out.println(">>>>>>>>>>>>>>>>>>>>Mark Up Entities Method List  :- " + markUpEntitylist);
				for each(var eMarkUp in markUpEntitylist)
				//while (markUps.hasMoreElements())
				{
					var markUpEntityId = EntityIDUtils.getInstance().getEntityId(eMarkUp);
					sysOut.out.println("########## Mark Up Entity Type Class #############"+eMarkUp.getClass());
			
					var markUpNmId = NmOid.newNmOid(markUpEntityId);
					var markUpobjId = markUpNmId.getOidObject();
					var rfObjectMarkUp = new refFact().getReference(markUpEntityId);
					
					sysOut.out.println("########"+"RefObject is "+rfObjectMarkUp.getObject());
					sysOut.out.println("##########  Start Mark up #############");
					
					
					var localWTMarkUp = rfObjectMarkUp.getObject();
		        
					sysOut.out.println("####Locked by#####"+localWTMarkUp.getLockerFullName());
					sysOut.out.println("####Owner#####"+localWTMarkUp.getOwnership().getOwner().getFullName());
					sysOut.out.println("getType "+localWTMarkUp.getType()+"\t isAllowCopyForward "+localWTMarkUp.isAllowCopyForward()+"\t getName "+localWTMarkUp.getName());
					eMarkUp.addProperty(new Property('Edm.String', 'AnnotationName', ValueType.PRIMITIVE, localWTMarkUp.getName()));
					eMarkUp.addProperty(new Property('Edm.String', 'LockedBy', ValueType.PRIMITIVE, localWTMarkUp.getLockerFullName()));
					eMarkUp.addProperty(new Property('Edm.String', 'Owner', ValueType.PRIMITIVE, localWTMarkUp.getOwnership().getOwner().getFullName()));
					eMarkUp.addProperty(new Property('Edm.String', 'CopyForward', ValueType.PRIMITIVE, localWTMarkUp.isAllowCopyForward()?"Enabled":"Disabled"));
					sysOut.out.println("##########  End Mark up #############");
					
					markUpMap.put(localWTMarkUp, eMarkUp);
		      
				}
				*/
				
				e.addProperty(new Property('Edm.String', 'RepName', ValueType.PRIMITIVE, repName));
				e.addProperty(new Property('Edm.String', 'Description', ValueType.PRIMITIVE, repDescription));
				e.addProperty(new Property('Edm.String', 'Thumbnail', ValueType.PRIMITIVE, thumbnailURL));
				//e.addProperty(new Property('Edm.String', 'Annotations', ValueType.PRIMITIVE, markUpMap));
				//e.addProperty(new Property('Edm.DateTimeOffset', 'ModifiedDate', ValueType.PRIMITIVE, repModified_time));
				objectEntityMap.put(localRep, e);
				if(i==1){
					sysOut.out.println("E1 =  "+e);
				}if(i==2){
					sysOut.out.println("E2 = "+e);
				}
				
			
			//sysOut.out.println("#### #### OBJ ID : "+objId+"; nmId: "+nmId+"; entityId: "+entityId);
			}
			
		
	}
	sysOut.out.println("####  MAP #### => "+objectEntityMap);
	 return objectEntityMap;
}

/**
 * Gets a set of related Entities for a given entity using navigation criteria.
 * @param navigationData
 * @returns Entity Collection of related (linked to) Entities
 */
function getRelatedEntityCollection(navigationData) {
    var HashMap = Java.type('java.util.HashMap');
    var HashSet = Java.type('java.util.HashSet');
    var ArrayList = Java.type('java.util.ArrayList');
	var sysOut=Java.type('java.lang.System');
    var WTPart = Java.type('wt.part.WTPart');
    var ObjectReference = Java.type('wt.fc.ObjectReference');
    var Collections = Java.type('java.util.Collections');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
    var WTHashSet = Java.type('wt.fc.collections.WTHashSet');
    var VersionControlHelper = Java.type("wt.vc.VersionControlHelper");
	var map = new HashMap();
    var targetName = navigationData.getTargetSetName();
	var annotationsList=new ArrayList();
	
	var sourceObjectsList = new WTArrayList(navigationData.getSourceObjects());
	
	if ("AnnotationDetails".equals(targetName)) { 
	
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			sysOut.out.println("###############DEWANK################### Source Objects "+sourceObject);
			
			var annotations  = ViewMarkUpHelper.service.getMarkUps(sourceObject);
	
			while(annotations.hasMoreElements()){
				
				annotationsList.add(annotations.nextElement());
			
				}
			
			sysOut.out.println("###############DEWANK################### RepresentationList "+annotationsList);
			map.put(sourceObject, annotationsList);
			sysOut.out.println("###############DEWANK################### Map -> "+ map);
		}
		
    }
	return map;
	
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    var WTPart = Java.type('wt.part.WTPart');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WTPartUsageLink = Java.type('wt.part.WTPartUsageLink');
    var WTPartDescribeLink = Java.type('wt.part.WTPartDescribeLink');
    var WTPartReferenceLink = Java.type('wt.part.WTPartReferenceLink');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');   
    var ObjectReference = Java.type('wt.fc.ObjectReference');

    if ("AnnotationDetails".equals(navName)) {

		// All tests passed
        return true;
    } 
	
	// must return null if navigation is not ours
    return null;
}