function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
	var HashMap = Java.type('java.util.HashMap');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	var objectEntityMap = new HashMap();
	var Enumeration= Java.type("java.util.Enumeration");
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var sysOut=Java.type('java.lang.System');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	var RfObject=Java.type('wt.fc.WTReference');
	var arrayList = Java.type('java.util.ArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTMarkUp=Java.type('wt.viewmarkup.WTMarkUp');
	var Viewable=Java.type('wt.viewmarkup.Viewable');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
	var WTException=Java.type('wt.util.WTException');
	var Representation=Java.type('wt.representation.Representation');
	var QueryResult=Java.type('wt.fc.QueryResult');
	var ContentHelper=Java.type('wt.content.ContentHelper');
	var repList=new arrayList();
	var markUpMap=new HashMap();
	var persistableObjects = OidHelper.getWTCollection(objects);
	var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
	var list = entityCollection.getEntities();
				
	for each(var e in list)
		{
			var markUpEntityId = EntityIDUtils.getInstance().getEntityId(e);
			sysOut.out.println("########## Mark Up Entity Type Class #############"+e.getClass());
			
			var markUpNmId = NmOid.newNmOid(markUpEntityId);
			var markUpobjId = markUpNmId.getOidObject();
			var rfObjectMarkUp = new refFact().getReference(markUpEntityId);		
			var localWTMarkUp = rfObjectMarkUp.getObject();
			var copyForward = localWTMarkUp.isAllowCopyForward()?"Enabled":"Disabled";
			var details = "Type: "+localWTMarkUp.getMarkUpType()+", Owner: "+localWTMarkUp.getOwnership().getOwner().getFullName()+", CopyForward: "+copyForward;
			var thumbnail = null;
			if(ContentHelper.service.getThumbnail(localWTMarkUp)!=null){
				
				thumbnail = ContentHelper.service.getDownloadURL(localWTMarkUp,ContentHelper.service.getThumbnail(localWTMarkUp));
			}
			
			e.addProperty(new Property('Edm.String', 'AnnotationName', ValueType.PRIMITIVE, localWTMarkUp.getName()));
			e.addProperty(new Property('Edm.String', 'Description', ValueType.PRIMITIVE, localWTMarkUp.getDescription()));
			e.addProperty(new Property('Edm.String', 'LockedBy', ValueType.PRIMITIVE, localWTMarkUp.getLockerFullName()));
			e.addProperty(new Property('Edm.String', 'Type', ValueType.PRIMITIVE, localWTMarkUp.getMarkUpType()));
			e.addProperty(new Property('Edm.String', 'Details', ValueType.PRIMITIVE, details));
			e.addProperty(new Property('Edm.String', 'Thumbnail', ValueType.PRIMITIVE, thumbnail));
			e.addProperty(new Property('Edm.String', 'Owner', ValueType.PRIMITIVE, localWTMarkUp.getOwnership().getOwner().getFullName()));
			e.addProperty(new Property('Edm.String', 'CopyForward', ValueType.PRIMITIVE, localWTMarkUp.isAllowCopyForward()?"Enabled":"Disabled"));
					
			markUpMap.put(localWTMarkUp, e);
		      
		}
	
	sysOut.out.println("####  MAP #### => "+markUpMap);
	 
	return markUpMap;
}

function function_EnableCopyForward(data, params) {
    // Prototype code
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var PersistenceHelper=Java.type('wt.fc.PersistenceHelper');
	var SessionHelper = Java.type('wt.session.SessionHelper');
	var currentUser = SessionHelper.getPrincipal();
	var sysOut=Java.type('java.lang.System');
	sysOut.out.println("#####YASHUL######## Parameters => "+params.getClass().getName()+"\n data => "+data);
	
	var paramHashMap= params;
	
	
	
	var boundWTMarkUp = paramHashMap.get('Annotations').getValue();
	
	var wtMarkUp = data.getProcessor().toObject(boundWTMarkUp, data);

	var result="";
	
	sysOut.out.println("\n WTMarkUp Value =>"+ wtMarkUp.getName());
	
	if(wtMarkUp.getLockerFullName()!=null)
	{
		if(wtMarkUp.isAllowCopyForward())
		{
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Already Enabled");
        }
        else
        {
			try
			{
				wtMarkUp.setAllowCopyForward(true);
                           
				sysOut.out.println("Saved or not => "+PersistenceHelper.manager.save(wtMarkUp));
						   
				result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Enabled");
			}
			catch(e)
			{
				result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, e.toString().contains("locked by a different principal")?"The object was locked by "+wtMarkUp.getLockerFullName()+" and cannot be modified by "+currentUser.getFullName():e);
			}
		}
	}
	else{
	result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "ATTENTION: Enable/Disable Copy Forward Cannot be Performed. You must lock the annotation before you can proceed");
	}
    
	return result;
}

function function_DisableCopyForward(data, params) {

    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var SessionHelper = Java.type('wt.session.SessionHelper');
	var currentUser = SessionHelper.getPrincipal();
	var PersistenceHelper=Java.type('wt.fc.PersistenceHelper');
	var sysOut=Java.type('java.lang.System');
	var paramHashMap= params;
	var boundWTMarkUp = paramHashMap.get('Annotations').getValue();
	var wtMarkUp = data.getProcessor().toObject(boundWTMarkUp, data);
	var result="";
	if(wtMarkUp.getLockerFullName()!=null) {
		if(!wtMarkUp.isAllowCopyForward()) {
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Already Disabled");
        }
        else {
			try {
					wtMarkUp.setAllowCopyForward(false);
					sysOut.out.println("Saved or not => "+PersistenceHelper.manager.save(wtMarkUp));
					result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Disabled");
				}
				catch(e) {
					result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, e.toString().contains("locked by a different principal")?"The object was locked by "+wtMarkUp.getLockerFullName()+" and cannot be modified by "+currentUser.getFullName():e);
				}
        }
	}
	else{
		result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "ATTENTION: Enable/Disable Copy Forward Cannot be Performed. You must lock the annotation before you can proceed");
	}
    
	return result;
}

function function_LockAnnotation(data, params) {

    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var PersistenceHelper=Java.type('wt.fc.PersistenceHelper');
	var SessionHelper = Java.type('wt.session.SessionHelper');
	var currentUser = SessionHelper.getPrincipal();
	var LockHelper=Java.type('wt.locks.LockHelper');
	var sysOut=Java.type('java.lang.System');
	var paramHashMap= params;
	var boundWTMarkUp = paramHashMap.get('Annotations').getValue();
	var wtMarkUp = data.getProcessor().toObject(boundWTMarkUp, data);
	var result="";
	if(wtMarkUp.getLockerFullName()==null) {
		try {
			LockHelper.service.lock(wtMarkUp);
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Locked");
		}
		catch(e) {
			sysOut.out.println("IN Catch : "+e+" Message : "+e.getMessage());
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, e.toString().contains("not authorized")?"The principal: "+currentUser.getFullName()+" is not authorized to modify":e);
		}
	}
	else{
		result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Already Locked By : "+wtMarkUp.getLockerFullName());
	}
	return result;
}

function function_UnlockAnnotation(data, params) {

    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var PersistenceHelper=Java.type('wt.fc.PersistenceHelper');
	var SessionHelper = Java.type('wt.session.SessionHelper');
	var currentUser = SessionHelper.getPrincipal();
	var LockHelper=Java.type('wt.locks.LockHelper');
	var sysOut=Java.type('java.lang.System');
	var paramHashMap= params;
	var boundWTMarkUp = paramHashMap.get('Annotations').getValue();
	var wtMarkUp = data.getProcessor().toObject(boundWTMarkUp, data);
	var result="";
	if(wtMarkUp.getLockerFullName()==null) {
		result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Already Unlocked");
	}
	else{
		if(currentUser.getFullName().equals(wtMarkUp.getLockerFullName())){
			LockHelper.service.unlock(wtMarkUp);
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Unlocked");
		}		
		else {
			result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "ATTENTION: Unlock Annotation Cannot be Performed. The annotation can only be unlocked by the user who locked it or by an Administrator");
		}
	}
	return result;
}