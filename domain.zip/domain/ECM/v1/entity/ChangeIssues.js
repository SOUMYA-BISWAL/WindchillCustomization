function getRelatedEntityCollection(navigationData) {
    var HashMap = Java.type('java.util.HashMap');
	var ArrayList = Java.type('java.util.ArrayList');
	var System=Java.type('java.lang.System');
	var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
	var ReportedAgainst = Java.type('wt.change2.ReportedAgainst');
	var Changeable2 = Java.type('wt.change2.Changeable2');
	var ProblemProduct = Java.type('wt.change2.ProblemProduct');
	var ChangeReferenceLink = Java.type('wt.change2.ChangeReferenceLink');
	var FlexibleChangeHelper = Java.type('wt.change2.flexible.FlexibleChangeHelper');
	var FlexibleChangeLinkBean = Java.type('com.ptc.windchill.enterprise.change2.flexible.FlexibleChangeLinkBean');
	var WTReference = Java.type('wt.fc.WTReference');
	var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var VersionableChangeItem = Java.type('wt.change2.VersionableChangeItem');
	
	var map = new HashMap();
    var targetName = navigationData.getTargetSetName();
	var reportedAgainstList =new ArrayList();
	var problemProductList =new ArrayList();
	var changeReferencesList =new ArrayList();
	
	var sourceObjectsList = new WTArrayList(navigationData.getSourceObjects());
	if ("ReportedAgainsts".equals(targetName)) { 
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			var queryResult = PersistenceHelper.manager.navigate(sourceObject, "theChangeable2", ReportedAgainst.class, false); // Static variables of Windchill Classes are not accessible
			for (var i = 0; i < queryResult.size(); i++) {
				var reportedAgainst = queryResult.nextElement();
				var changeable = reportedAgainst.getChangeable2();
				reportedAgainstList.add(changeable);
			}
			map.put(sourceObject, reportedAgainstList);
		}
    }
	
	if ("ProblemProducts".equals(targetName)) { 
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			var queryResult = PersistenceHelper.manager.navigate(sourceObject, "theWTPartMaster", ProblemProduct.class, false); // Static variables of Windchill Classes are not accessible
			for (var i = 0; i < queryResult.size(); i++) {
				var problemProduct = queryResult.nextElement();
				var partMaster = problemProduct.getWTPartMaster();
				problemProductList.add(partMaster);
			}
			map.put(sourceObject, problemProductList);
		}
    }
	if ("ChangeReferences".equals(targetName)) { 
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			var flexChangeLinks = FlexibleChangeHelper.getService().getFlexibleChangeLinks(sourceObject,"ALL", true, null);
			var beans = FlexibleChangeLinkBean.getFlexibleChangeLinkBeans(sourceObject,flexChangeLinks);
			for(var j = 0; j < beans.size(); j++) {
				ref = new ReferenceFactory().getReference(beans.get(j).getOid());
				versionableChangeItem = ref.getObject();
				changeReferencesList.add(versionableChangeItem);
			}
			map.put(sourceObject, changeReferencesList);
		}
    }
	
	
	return map;
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    return getHelper().isValidNavigation(navName, sourceObject, targetObjectId, processorData);
}

function getHelper() {
    var ChangeMgmtHelper = Java.type('com.ptc.odata.changemgmt.util.ChangeMgmtHelper');
    return new ChangeMgmtHelper();
}

