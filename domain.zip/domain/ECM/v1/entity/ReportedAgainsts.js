function getRelatedEntityCollection(navigationData) {
    return getHelper().getAffectedObjCollection(navigationData);
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    return getHelper().isValidNavigation(navName, sourceObject, targetObjectId, processorData);
}

function processAdditionalAttributes(entity, object, data, processor) {
    return getHelper().processReportedAgainstAdditionalAttributes(entity, object, data);
}

function getHelper() {
    var ChangeMgmtHelper = Java.type('com.ptc.odata.changemgmt.util.ChangeMgmtHelper');
    return new ChangeMgmtHelper();
}

