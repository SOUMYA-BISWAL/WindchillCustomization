function getProperty(propertyDescriptor, property, entityObject, processorData) {
    return getHelper().getLongDescriptionProperty(propertyDescriptor, property, entityObject, processorData);
}

/*
function getAttributesFromJSON(jsonValue) {
    return getHelper().getLongDescriptionAttributesFromJSON(jsonValue);
}
*/

function getAttributeDataCollection(processorData, entityProperty, complexValue, previousValue) {
    return getHelper().getLongDescriptionAttributeDataCollection(processorData, entityProperty, complexValue, previousValue);
}

function getHelper() {
    var ChangeMgmtHelper = Java.type('com.ptc.odata.changemgmt.util.ChangeMgmtHelper');
    return new ChangeMgmtHelper();
}
