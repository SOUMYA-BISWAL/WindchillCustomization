/**
 * Invokes InfoEngine task with the given parameters and returns collection of PTC.IE.Group entities.
 * 
 * @param data Data for processing action request
 * @param params Parameters required to invoke the InfoEngine task
 * @returns Collection of PTC.ECM.ChangeIssue entities
 */
function action_newChangeIssue(data, params) {
	
	// Import necessary Classes
	var System = Java.type('java.lang.System');
	var WTContainerRef = Java.type('wt.inf.container.WTContainerRef');
	var WTContainerHelper = Java.type('wt.inf.container.WTContainerHelper');
	var WTChangeIssue = Java.type('wt.change2.WTChangeIssue');
	var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
	var ActionResult = Java.type("com.ptc.odata.core.entity.processor.ActionResult");
	var WTReference = Java.type('wt.fc.WTReference');
	var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var Changeable2 = Java.type('wt.change2.Changeable2');
	var ReportedAgainst = Java.type('wt.change2.ReportedAgainst');
	var File = Java.type('java.io.File');
	var ApplicationData = Java.type('wt.content.ApplicationData');
	var ChangeReferenceLink = Java.type('wt.change2.ChangeReferenceLink');
	var ProblemProduct = Java.type('wt.change2.ProblemProduct');
	var ContentRoleType = Java.type('wt.content.ContentRoleType');
	var Transaction = Java.type('wt.pom.Transaction');
	var ContentServerHelper = Java.type('wt.content.ContentServerHelper');
	
	// Problem Report Creation Pre-requisite Variables
	var name = params.get('name').getValue();
	var description = params.get('description').getValue();
	var organisation = params.get('organisation').getValue();
	var product = params.get('product').getValue();
	var affectedObjectID = params.get('affectedObjectId').getValue();
	var endItemId = params.get('endItemId').getValue();
	var changeItemId = params.get('changeItemId').getValue();
	//var attachementFilePath = params.get('attachementFilePath').getValue();
	var containerPath = "/wt.inf.container.OrgContainer="+organisation+"/wt.pdmlink.PDMLinkProduct="+product;
	var containerRef = WTContainerHelper.service.getByPath(containerPath);
	var transaction = new Transaction();
	var result = new ActionResult();
	
	// New Problem Report Creation and Setting Attributes - Need to handle NULL Case
	var changeIssue = WTChangeIssue.newWTChangeIssue();
	changeIssue.setContainerReference(containerRef);
	changeIssue.setName(name);
	changeIssue.setDescription(description);
	changeIssue.setDescription(description);
	
	// Database Commit
	changeIssue = PersistenceHelper.manager.store(changeIssue);
	
	// Affected Objects - Need to handle NULL Case
	var changeableReference = new ReferenceFactory().getReference(affectedObjectID);
	var changeableObject = changeableReference.getObject();
	var reportedAgainstRelation = ReportedAgainst.newReportedAgainst(changeableObject,changeIssue);
	reportedAgainstRelation = PersistenceHelper.manager.store(reportedAgainstRelation);
	
	// Affected EndItems - Need to handle NULL Case
	var changeableEndItemReference = new ReferenceFactory().getReference(endItemId);
	var changeableEndItemObject = changeableEndItemReference.getObject();
	if(changeableEndItemObject.isEndItem()) {
		var problemProductRelation = ProblemProduct.newProblemProduct(changeableEndItemObject,changeIssue);
		problemProductRelation = PersistenceHelper.manager.store(problemProductRelation);		
	}
	
	// Associated Reference Objects
	var changeItemReference = new ReferenceFactory().getReference(changeItemId);
	var changeItemObject = changeItemReference.getObject();
	var changeReferenceLink = ChangeReferenceLink.newChangeReferenceLink(changeIssue,changeItemObject);
	changeReferenceLink = PersistenceHelper.manager.store(changeReferenceLink);
	
	
	// Database Transaction
	//transaction.start();
	
	// Attachement -  Need to Handle NULL CASES
	/*
	var file = new File(attachementFilePath);
	var changeIssueAD = ApplicationData.newApplicationData(changeIssue);
	changeIssueAD.setFileName(file.getName());
	changeIssueAD.setUploadedFromPath(attachementFilePath);
	changeIssueAD.setRole(ContentRoleType.SECONDARY);
	var inputstream = new java.io.FileInputStream(file);
	ContentServerHelper.service.updateContent(changeIssue, changeIssueAD,inputstream);
	*/
	//transaction.commit();
	//transaction=null;
	
	// Returning new created ChangeIssue as action result
	changeIssue = PersistenceHelper.manager.refresh(changeIssue);
    var changeIssueEntity = data.getProcessor().toEntity(changeIssue, data);
    result.setReturnedObject(changeIssueEntity);
    return result;
}

/*

	Manual Creation of WC TYPE to ODATA ENTITY

*/
function parseChangeIssue(changeIssue)	{
	
	var EntityCollection = Java.type("org.apache.olingo.commons.api.data.EntityCollection");
	var Entity = Java.type("org.apache.olingo.commons.api.data.Entity");
	var Property = Java.type("org.apache.olingo.commons.api.data.Property");
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	
	var changeIssueEntity = new EntityCollection();
	var entities = changeIssueEntity.getEntities();
	var entity = new Entity();
	entity.setType("PTC.ECM.ChangeIssue");
	
	var prop = new Property("Edm.String", "Name", ValueType.PRIMITIVE, changeIssue.getName());
	entity.addProperty(prop);
	prop = new Property("Edm.String", "ID", ValueType.PRIMITIVE, "OR:"+changeIssue.getPersistInfo().getObjectIdentifier());
	entity.addProperty(prop);
	prop = new Property("Edm.String", "Number", ValueType.PRIMITIVE, changeIssue.getNumber());
	entity.addProperty(prop);
	prop = new Property("Edm.String", "Description", ValueType.PRIMITIVE, changeIssue.getDescription());
	entity.addProperty(prop);
	prop = new Property("Edm.String", "Requester", ValueType.PRIMITIVE, changeIssue.getRequester());
	entity.addProperty(prop);
	prop = new Property("Edm.EnumType", "Category", ValueType.ENUM, changeIssue.getCategory());
	entity.addProperty(prop);
	prop = new Property("Edm.EnumType", "Priority", ValueType.ENUM, changeIssue.getIssuePriority());
	entity.addProperty(prop);
	prop = new Property("Edm.DateTimeOffset", "NeedDate", ValueType.PRIMITIVE, changeIssue.getNeedDate());
	entity.addProperty(prop);
	prop = new Property("Edm.String", "Location", ValueType.PRIMITIVE, changeIssue.getLocation());
	entity.addProperty(prop);
	//prop = new Property("Edm.String", "VersionID", ValueType.PRIMITIVE, changeIssue.getVersionInfo().getIdentifier());
	//entity.addProperty(prop);
	prop = new Property("Edm.Boolean", "Latest", ValueType.PRIMITIVE, changeIssue.isLatest());
	entity.addProperty(prop);
	prop = new Property("Edm.DateTimeOffset", "CreatedOn", ValueType.PRIMITIVE, changeIssue.getCreateTimestamp());
	entity.addProperty(prop);
	prop = new Property("Edm.DateTimeOffset", "LastModified", ValueType.PRIMITIVE, changeIssue.getModifyTimestamp());
	entity.addProperty(prop);
	
	entities.add(entity);
	return changeIssueEntity;
	
}