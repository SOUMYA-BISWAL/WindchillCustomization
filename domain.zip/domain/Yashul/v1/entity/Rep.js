function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
	var HashMap = Java.type('java.util.HashMap');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	var objectEntityMap = new HashMap();
	var Enumeration= Java.type("java.util.Enumeration");
	var WTProperties= Java.type("wt.util.WTProperties");
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var sysOut=Java.type('java.lang.System');
    var Locale=Java.type('java.util.Locale');
    var UIHelper=Java.type('com.ptc.wvs.server.ui.UIHelper');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	var RfObject=Java.type('wt.fc.WTReference');
	var arrayList = Java.type('java.util.ArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTMarkUp=Java.type('wt.viewmarkup.WTMarkUp');
	var Viewable=Java.type('wt.viewmarkup.Viewable');
	var ApplicationData = Java.type('wt.content.ApplicationData');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
	var WTException=Java.type('wt.util.WTException');
	var Representation=Java.type('wt.representation.Representation');
	var QueryResult=Java.type('wt.fc.QueryResult');
	var ContentHelper=Java.type('wt.content.ContentHelper');
	var repList=new arrayList();
	var persistableObjects = OidHelper.getWTCollection(objects);
	sysOut.out.println("hi123456778Entities Method persistableObjects  :- "+persistableObjects);
	var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
	var list = entityCollection.getEntities();
	var i=0;
	var repURL =null;
	for each(var e in list) {
		i++;
		if(e!=null){
			var entityId = EntityIDUtils.getInstance().getEntityId(e);
			var nmId = NmOid.newNmOid(entityId);
			var objId = nmId.getOidObject();
			var rfObjectRep = new refFact().getReference(entityId);
			var localRep=null;
			if (rfObjectRep.getObject() instanceof Representation) {
				localRep= rfObjectRep.getObject();
			}
			var repName=localRep.getName();
			var repDescription=localRep.getDescription();
			var repCreated_Time= localRep.getPersistInfo().getCreateStamp();
			var repModified_time= localRep.getPersistInfo().getModifyStamp();
			var repOwner = localRep.getOwnership().getOwner().getFullName();
			var details = UIHelper.getDerivedImageDetailsHTML(localRep, Locale.getDefault());
			
			
			var thumbnailURL=null;
			if(ContentHelper.service.getThumbnail(localRep)!=null) {
				thumbnailURL = ContentHelper.service.getDownloadURL(localRep,ContentHelper.service.getThumbnail(localRep));
			}
			var hostname = WTProperties.getServerProperties().getProperty("wt.rmi.server.hostname");
			
			localRep = ContentHelper.service.getContents(localRep);
			var enumeration = ContentHelper.getApplicationData(localRep).elements();
			while (enumeration.hasMoreElements()) {
				var app_object = enumeration.nextElement();
				if (app_object instanceof ApplicationData && app_object.getRole().toString().equals("PRODUCT_VIEW_ED")) {
					var repRAWUrl = ""+ContentHelper.getDownloadURL(localRep, app_object, false);
					repURL = "http://"+hostname+"/Windchill/wtcore/jsp/wvs/edrview.jsp?url="+repRAWUrl.replaceAll("&forceDownload=true","&objref=OR%3A"+repRAWUrl.substring(repRAWUrl.indexOf("&ContentHolder=")+"&ContentHolder=".length(), repRAWUrl.indexOf("&forceDownload")));
					break;
				}
			}
			e.addProperty(new Property('Edm.String', 'RepName', ValueType.PRIMITIVE, repName));
			e.addProperty(new Property('Edm.String', 'Description', ValueType.PRIMITIVE, repDescription));
			e.addProperty(new Property('Edm.String', 'Thumbnail', ValueType.PRIMITIVE, thumbnailURL));
			e.addProperty(new Property('Edm.String', 'Owner', ValueType.PRIMITIVE, repOwner));
			e.addProperty(new Property('Edm.String', 'CreoViewURL', ValueType.PRIMITIVE, repURL));
			e.addProperty(new Property('Edm.String', 'Details', ValueType.PRIMITIVE, details));
			objectEntityMap.put(localRep, e);
		}
	}
	 return objectEntityMap;
}

/**
 * Gets a set of related Entities for a given entity using navigation criteria.
 * @param navigationData
 * @returns Entity Collection of related (linked to) Entities
 */
function getRelatedEntityCollection(navigationData) {
    var HashMap = Java.type('java.util.HashMap');
    var HashSet = Java.type('java.util.HashSet');
    var ArrayList = Java.type('java.util.ArrayList');
	var sysOut=Java.type('java.lang.System');
    var WTPart = Java.type('wt.part.WTPart');
    var ObjectReference = Java.type('wt.fc.ObjectReference');
    var Collections = Java.type('java.util.Collections');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
    var WTHashSet = Java.type('wt.fc.collections.WTHashSet');
    var VersionControlHelper = Java.type("wt.vc.VersionControlHelper");
	var map = new HashMap();
    var targetName = navigationData.getTargetSetName();
	var annotationsList=new ArrayList();
	
	var sourceObjectsList = new WTArrayList(navigationData.getSourceObjects());
	if ("Annotations".equals(targetName)) { 
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			var annotations  = ViewMarkUpHelper.service.getMarkUps(sourceObject);
			while(annotations.hasMoreElements()){
				annotationsList.add(annotations.nextElement());
			}
			map.put(sourceObject, annotationsList);
		}
    }
	return map;
	
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    var WTPart = Java.type('wt.part.WTPart');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WTPartUsageLink = Java.type('wt.part.WTPartUsageLink');
    var WTPartDescribeLink = Java.type('wt.part.WTPartDescribeLink');
    var WTPartReferenceLink = Java.type('wt.part.WTPartReferenceLink');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');   
    var ObjectReference = Java.type('wt.fc.ObjectReference');

    if ("Annotations".equals(navName)) {
        return true;
    }
    return null;
}