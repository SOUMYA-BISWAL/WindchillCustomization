/**
 * Gets a set of related Entities for a given entity using navigation criteria.
 * @param navigationData
 * @returns Entity Collection of related (linked to) Entities
 */
function getRelatedEntityCollection(navigationData) {
    var HashMap = Java.type('java.util.HashMap');
    var HashSet = Java.type('java.util.HashSet');
    var ArrayList = Java.type('java.util.ArrayList');
	var sysOut=Java.type('java.lang.System');
    var WTPart = Java.type('wt.part.WTPart');
    var ObjectReference = Java.type('wt.fc.ObjectReference');
    var Collections = Java.type('java.util.Collections');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
    var WTHashSet = Java.type('wt.fc.collections.WTHashSet');
    var VersionControlHelper = Java.type("wt.vc.VersionControlHelper");
	var map = new HashMap();
    var targetName = navigationData.getTargetSetName();
	var repList=new ArrayList();
	var sourceObjectsList = new WTArrayList(navigationData.getSourceObjects());
	if ("Representations".equals(targetName)) {
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);			
			var visHelper = new VisualizationHelper();
			var repqr = visHelper.getRepresentations(sourceObject);
	
			while(repqr.hasMoreElements()){
				repList.add(repqr.nextElement());
			}
			map.put(sourceObject, repList);
		}
    }
	return map;
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    var WTPart = Java.type('wt.part.WTPart');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WTPartUsageLink = Java.type('wt.part.WTPartUsageLink');
    var WTPartDescribeLink = Java.type('wt.part.WTPartDescribeLink');
    var WTPartReferenceLink = Java.type('wt.part.WTPartReferenceLink');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');   
    var ObjectReference = Java.type('wt.fc.ObjectReference');
    if ("Representations".equals(navName)) {
        return true;
    } 
    return null;
}

function function_getDefaultCreoViewURL(data, params) { // This function takes Viewable as input and provides default creo view URL.
   
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var VisualizationHelper = Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTProperties = Java.type('wt.util.WTProperties');
	var PersistenceHelper=Java.type('wt.fc.PersistenceHelper');
	var sysOut=Java.type('java.lang.System');
	var paramHashMap= params;
	var boundWTMarkUp = paramHashMap.get('ChangeableObjects').getValue();
	var inputID = boundWTMarkUp.getProperty("ID").toString().substring(3);
	var viewableObject = data.getProcessor().toObject(boundWTMarkUp, data);
	var result="";
	var visHelper = new VisualizationHelper();
	var defRepRawURL = visHelper.getDefaultVisualizationData(inputID,false,new java.util.Locale("en"))[0];
	if(defRepRawURL!=null && !defRepRawURL.equals("")) {
		var hostnameGlobal = WTProperties.getServerProperties().getProperty("wt.rmi.server.hostname");
		var defRepURL = "http://"+hostnameGlobal+defRepRawURL.substring(defRepRawURL.indexOf("'")+1,defRepRawURL.indexOf(',')-1);
		sysOut.out.println("################Yashul############## Default Representation defRepURL =>  "+defRepURL);
		result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE,defRepURL);
	}
	else{
		result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE,"No Defaut Representation Found");
	}
	
	return result;
}



