/**
 * Invokes InfoEngine task with the given parameters and returns collection of PTC.IE.Group entities.
 * 
 * @param data Data for processing action request
 * @param params Parameters required to invoke the InfoEngine task
 * @returns Collection of PTC.ECM.ChangeIssue entities
 */
function function_TestFunction() {
	var System = Java.type('java.lang.System');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	
	System.out.println("Soumaya Response METHOD_SERVER");
	result = new Property('Edm.String', 'Status', ValueType.PRIMITIVE, "Soumya Response POST_MAN");
	//result = "hhuuhhuhuuuhhuuhh";
	return result;
	
}