/**
 * Invokes InfoEngine task with the given parameters and returns collection of PTC.IE.Group entities.
 * 
 * @param data Data for processing action request
 * @param params Parameters required to invoke the InfoEngine task
 * @returns Collection of PTC.ECM.ChangeIssue entities
 */
 
// Import necessary Classes
var System = Java.type('java.lang.System');
var System = Java.type('java.lang.System');
var WTContainerRef = Java.type('wt.inf.container.WTContainerRef');
var WTContainerHelper = Java.type('wt.inf.container.WTContainerHelper');
var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
var ActionResult = Java.type("com.ptc.odata.core.entity.processor.ActionResult");
var WTReference = Java.type('wt.fc.WTReference');
var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
var File = Java.type('java.io.File');
var ApplicationData = Java.type('wt.content.ApplicationData');
var ContentRoleType = Java.type('wt.content.ContentRoleType');
var Transaction = Java.type('wt.pom.Transaction');
var ContentServerHelper = Java.type('wt.content.ContentServerHelper');
var WTDocument = Java.type('wt.doc.WTDocument');
var URL = Java.type('java.net.URL');
var HttpURLConnection = Java.type('java.net.HttpURLConnection');
var String = Java.type('java.lang.String');
var StringBuilder = Java.type('java.lang.StringBuilder');
var InputStreamReader = Java.type('java.io.InputStreamReader');
var BufferedReader = Java.type('java.io.BufferedReader');
var JSONObject = Java.type('org.json.JSONObject');
var FileWriter = Java.type('java.io.FileWriter');
var Base64 = Java.type('java.util.Base64');
var QuerySpec = Java.type('wt.query.QuerySpec');
var Integer = Java.type('java.lang.Integer');
var SearchCondition = Java.type('wt.query.SearchCondition');
var VersionControlHelper = Java.type('wt.vc.VersionControlHelper');
var ContentHelper = Java.type('wt.content.ContentHelper');
var WorkInProgressHelper = Java.type('wt.vc.wip.WorkInProgressHelper');



function function_fetchDocument(data) {
	var docNumber="DOC0000000381";
	var document = new WTDocument();
	File file=null;
	var searchCondition= new SearchCondition(WTDocument.class, "master>number", SearchCondition.EQUAL, docNumber, true)
	var querySpec = new QuerySpec(WTDocument.class);
	querySpec.appendWhere((WhereExpression)searchCondition, new Array(0));				
	System.out.println(querySpec);
	var queryResult = PersistenceHelper.manager.find((StatementSpec)Query);
	
}