/*
function readEntityData(EntityProcessorData) {
	var sysOut=Java.type('java.lang.System');
	sysOut.out.println("Calling readEntitySetData");
	return readEntitySetData(EntityProcessorData);
	//sysOut.out.println("bye bye readEntityData");
}
*/
/*

function readEntitySetData(EntityProcessorData) {
	
	var sysOut=Java.type('java.lang.System');
	sysOut.out.println("Inside readEntitySetData");
	var ArrayList = Java.type('java.util.ArrayList');
	var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var list = new ArrayList();
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var RfObject=Java.type('wt.fc.WTReference');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	
	//var entityId = EntityIDUtils.getInstance().getEntityId(EntityProcessorData);
	//var nmId = NmOid.newNmOid(entityId);
	//var objId = nmId.getOidObject();
	
	//rfObject = new refFact().getReference(entityId);
	//sysOut.out.println("####YASHUL####"+"RefObject is "+rfObject.getObject());
	//var visHelper = new VisualizationHelper();
	//var repqr = visHelper.getRepresentations(rfObject.getObject());
			
		
	
	var entityId = EntityIDUtils.getInstance().getRequestedId(EntityProcessorData);
	
	var rfObject = new refFact().getReference(entityId);
	
	var visHelper = new VisualizationHelper();
	var repqr = visHelper.getRepresentations(rfObject.getObject());
	
	sysOut.out.println("YASHULREAD#### Hey i am in Read Entity Set Data Method");
	sysOut.out.println("Entity Processor Data :- "+entityId);
	sysOut.out.println("Repqr :- "+repqr.getClass());
	//var listC = Collections.list(repqr);
	
	while(repqr.hasMoreElements()){
		list.add(repqr.nextElement());
	}
	
	sysOut.out.println("list.size :- "+list.size()+"\n List READ  = "+list);
	return list;
}
*/
function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
	var HashMap = Java.type('java.util.HashMap');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	var objectEntityMap = new HashMap();
	var Enumeration= Java.type("java.util.Enumeration");
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var sysOut=Java.type('java.lang.System');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	var RfObject=Java.type('wt.fc.WTReference');
	var localRep = Java.type('wt.viewmarkup.DerivedImage');
	var arrayList = Java.type('java.util.ArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTMarkUp=Java.type('wt.viewmarkup.WTMarkUp');
	var Viewable=Java.type('wt.viewmarkup.Viewable');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
	var WTException=Java.type('wt.util.WTException');
	var Representation=Java.type('wt.representation.Representation');
	var QueryResult=Java.type('wt.fc.QueryResult');
	var ContentHelper=Java.type('wt.content.ContentHelper');
	var repList=new arrayList();
	var entityIdPart = EntityIDUtils.getInstance().getRequestedId(processorData);
	sysOut.out.println("Method EntityIDPart  :- "+entityIdPart);
	
	var rfObject = new refFact().getReference(entityIdPart);
	
	var visHelper = new VisualizationHelper();
	var repqr = visHelper.getRepresentations(rfObject.getObject());
	
	while(repqr.hasMoreElements()){
		repList.add(repqr.nextElement());
	}
	sysOut.out.println("replist.size :- "+repList.size()+"\n repList READ  = "+repList);
	
	sysOut.out.println("Entities Method objects class  :- "+objects.getClass());
	sysOut.out.println("Entities Method objects  :- "+objects);
	
	
	var persistableObjects = OidHelper.getWTCollection(repList);
	
	sysOut.out.println("Entities Method persistableObjects  :- "+persistableObjects);
	
	var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
	var list = entityCollection.getEntities();
	sysOut.out.println("Entities Method List  :- "+list);
	var i=0;
	
	for each(var e in list) { // Entities Loop
	i++;
		if(e!=null){
			var entityId = EntityIDUtils.getInstance().getEntityId(e);
			var nmId = NmOid.newNmOid(entityId);
			var objId = nmId.getOidObject();
			var rfObjectRep = new refFact().getReference(entityId);
			sysOut.out.println("####YASHUL####"+"RefObject is "+rfObjectRep.getObject());
			
			/*
			var visHelper = new VisualizationHelper();
			var repqr = visHelper.getRepresentations(rfObject.getObject());
			 */
				
				
			if (rfObjectRep.getObject() instanceof Representation)
			{
				localRep= rfObjectRep.getObject();
				sysOut.out.println("Derived Image Identity is "+localRep.getName());
		
			}
				
				//var repProp=rep;
				//rep = ContentHelper.service.getContents(rep);
				var repName=localRep.getName();
				var repDescription=localRep.getDescription();
				var repCreated_Time= localRep.getPersistInfo().getCreateStamp();
				var repModified_time= localRep.getPersistInfo().getModifyStamp();
				
				sysOut.out.print("##########YASHUL#############\n"+localRep.getName());
				sysOut.out.print(">>>> "+localRep.getName());
				sysOut.out.println("Test >>>> "+localRep.getDescription()+" "+localRep.isDefaultRepresentation()+" "+localRep.getRepresentable().getIdentity());
				sysOut.out.println("Modify date:"+repModified_time);
				sysOut.out.println("created time:"+repCreated_Time);
				sysOut.out.println("########## YASHUL END #############");
				
				e.addProperty(new Property('Edm.String', 'RepName', ValueType.PRIMITIVE, repName));
				e.addProperty(new Property('Edm.String', 'Description', ValueType.PRIMITIVE, repDescription));
				e.addProperty(new Property('Edm.DateTimeOffset', 'Modified Date', ValueType.PRIMITIVE, repModified_time));
				objectEntityMap.put(localRep, e);
				if(i==1){
					sysOut.out.println("E1 =  "+e);
				}if(i==2){
					sysOut.out.println("E2 = "+e);
				}
				
			
			//sysOut.out.println("####YASHUL#### OBJ ID : "+objId+"; nmId: "+nmId+"; entityId: "+entityId);
			}
			
		
	}
	sysOut.out.println("#### YASHUL MAP #### => "+objectEntityMap);
	 return objectEntityMap;
}