/**
 * Invokes InfoEngine task with the given parameters and returns collection of PTC.IE.Group entities.
 * 
 * @param data Data for processing action request
 * @param params Parameters required to invoke the InfoEngine task
 * @returns Collection of PTC.ECM.ChangeIssue entities
 */
 
// Import necessary Classes
var System = Java.type('java.lang.System');
var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
var WTDocument = Java.type('wt.doc.WTDocument');
var String = Java.type('java.lang.String');
var TypeIdentifier = Java.type('com.ptc.core.meta.common.TypeIdentifier');
var WCTypeIdentifier = Java.type('com.ptc.core.meta.common.impl.WCTypeIdentifier');
var TypeDefinitionReference = Java.type('wt.type.TypeDefinitionReference');
var DocumentType = Java.type('wt.doc.DocumentType');
var TypeHelper = Java.type('com.ptc.core.foundation.type.server.impl.TypeHelper');
var TypedUtilityServiceHelper = Java.type('wt.type.TypedUtilityServiceHelper');
var WTContainerRef = Java.type('wt.inf.container.WTContainerRef');
var WTProperties = Java.type('wt.util.WTProperties');
var WTContainerHelper = Java.type('wt.inf.container.WTContainerHelper');
var Property = Java.type('org.apache.olingo.commons.api.data.Property');
var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');


function action_createSubtypeDocument(data,params) {
	var docName = params.get('docName').getValue();
	var docNumber = params.get('docNumber').getValue();
	var container = params.get('container').getValue();
	var properties = WTProperties.getLocalProperties();
    var wtProperties = properties.getProperty("wt.webservices.doctype", "D:\\ptc\\Windchill_11.0\\Windchill\\codebase");
	var customType = TypeHelper.getTypeIdentifier(wtProperties);
	var customTDR = TypedUtilityServiceHelper.service.getTypeDefinitionReference(customType.getTypename());
	var containerRef = WTContainerHelper.service.getByPath(container);
	var doc = WTDocument.newWTDocument();
	doc.setName(docName);
	doc.setNumber(docNumber);
	doc.setContainerReference(containerRef);
	doc.setTypeDefinitionReference(customTDR);
	doc = PersistenceHelper.manager.store(doc);
	return doc;
	
}