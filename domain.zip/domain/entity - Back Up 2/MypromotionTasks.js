function readEntitySetData(processorData) {
    // Prototype code

    var Collections = Java.type('java.util.Collections');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');
	var sysout=Java.type('java.lang.System');
	var string =Java.type('java.lang.String');
	var prNumber =Java.type('java.lang.String');
	var contName =Java.type('java.lang.String');
	var persistable = Java.type('wt.fc.Persistable');
	var pr1 = Java.type('wt.maturity.PromotionNotice');
    var currentUser = SessionHelper.getPrincipal();
	var ArrayList = Java.type('java.util.ArrayList');
	  var list = new ArrayList();
    var itemList = Collections.list(WorkflowHelper.service.getWorkItems(currentUser));
	sysout.out.println("## readEntitySetData ## "+itemList);
	for(var i = 0; i < itemList.size(); i++) {
		
		var wi = Java.type('wt.workflow.work.WorkItem');
		wi=itemList[i];
		string=wi.getPrimaryBusinessObject().getObject().getType();
		sysout.out.println("### objType ####"+string);
		if(string.contains("Promotion Request"))
		{
			sysout.out.println("### Inside ####");
			list.add(wi);
			persistable =wi.getPrimaryBusinessObject().getObject();
			pr1 =persistable;
			prNumber= pr1.getNumber();
			contName= pr1.getContainerName();
			sysout.out.println("### PRNUMBER ####"+prNumber+"containerName"+contName+"State"+pr1.getState().toString());
		
		}
	}
		sysout.out.println("### LISTTTTT "+list +"---------   "+list.size());
    return list;
}


function toEntities(objects, processorData) {
    // Prototype code
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var ComplexValue = Java.type('org.apache.olingo.commons.api.data.ComplexValue');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ArrayList = Java.type('java.util.ArrayList');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var sysout=Java.type('java.lang.System');
	var owner= Java.type('wt.ownership.Ownership');
	var contName =Java.type('java.lang.String');
	var str =Java.type('java.lang.String');
	var temp = Java.type('java.lang.String');
	var stat12 = Java.type('java.lang.String');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var Class = Java.type('java.lang.Class');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
	var pr1 = Java.type('wt.maturity.PromotionNotice');
	var prNum =Java.type('java.lang.String');
	var prName =Java.type('java.lang.String');
	var sub =Java.type('java.lang.String');
	var role12 = Java.type('java.lang.String');
	var v1 =Java.type('java.util.Vector');
	var currentUser = SessionHelper.getPrincipal();
    var currentUserReference = WTPrincipalReference.newWTPrincipalReference(currentUser);
    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
    var persistableObjects = OidHelper.getWTCollection(objects);
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
	  var list123 = new ArrayList();
	  sysout.out.println("list size ### "+list.size());
    for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
		var persistable = Java.type('wt.fc.Persistable');
        var workItem = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
		sysout.out.println("WORKITEM GETTING  ### "+workItem);
		
		persistable=workItem.getPrimaryBusinessObject().getObject();
		pr1=persistable;
		str=pr1.getState().toString();
		prNum= pr1.getNumber();
		prName= pr1.getName();
		contName= pr1.getContainerName();
		owner = workItem.getOwnership();
		stat12=workItem.getStatus().toString();
		role12=workItem.getRole().toString();
		var ct1 =workItem.getCreateTimestamp().toString()
		sub="Promotion Request -" + prNum +','+prName;
		temp =workItem.toString();
		var tokenizer = Java.type('java.util.StringTokenizer');
		var taskNumber = Java.type('java.lang.String');
		tokenizer = new tokenizer(temp, ":");
				     while (tokenizer.hasMoreTokens()){
						
				    list123.add(tokenizer.nextToken());
					sysout.out.println("token asda### "+list123); 
				     }
		 taskNumber= list123.get(1);
        var assignments = PersistenceHelper.manager.navigate(workItem, 'theWfAssignment', Class.forName('wt.workflow.work.WorkItemLink'), true);
        var wfAssignment = assignments.nextElement();
        var assignedTo = owner.getOwner().getName();
       /* var principals = wfAssignment.getPrincipals();
        if (principals !== undefined && principals.contains(currentUserReference)) {
            assignedTo = currentUser.getAuthenticationName();
        }*/
        var activities = PersistenceHelper.manager.navigate(wfAssignment, 'activity', Class.forName('wt.workflow.work.ActivityAssignmentLink'), true);
        var activity = activities.nextElement();
        var deadline = activity.getDeadline();
        var name = activity.getName();
        var instructions = activity.getInstructions();
		

        e.addProperty(new Property('Edm.String', 'Name', ValueType.PRIMITIVE, name));
        e.addProperty(new Property('Edm.String', 'Instructions', ValueType.PRIMITIVE, instructions));
        e.addProperty(new Property('Edm.String', 'AssignedTo', ValueType.PRIMITIVE, assignedTo));
        e.addProperty(new Property('Edm.DateTimeOffset', 'Deadline', ValueType.PRIMITIVE, deadline));
		e.addProperty(new Property('Edm.String', 'State', ValueType.PRIMITIVE, str));
		e.addProperty(new Property('Edm.String', 'PromotionNoticeNumber', ValueType.PRIMITIVE, prNum));
		e.addProperty(new Property('Edm.String', 'Context', ValueType.PRIMITIVE, contName));
		e.addProperty(new Property('Edm.String', 'Subject', ValueType.PRIMITIVE, sub));
		e.addProperty(new Property('Edm.String', 'TaskNumber', ValueType.PRIMITIVE, taskNumber));
		e.addProperty(new Property('Edm.String', 'Status', ValueType.PRIMITIVE, stat12));
		e.addProperty(new Property('Edm.String', 'Role', ValueType.PRIMITIVE, role12));
		e.addProperty(new Property('Edm.String', 'Assigned', ValueType.PRIMITIVE, ct1));
        objectEntityMap.put(workItem, e);
		list123.clear();
    }

    return objectEntityMap;
}