function readEntitySetData(processorData) {

    var Collections = Java.type('java.util.Collections');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');	
	var string =Java.type('java.lang.String');
	var currentUser = SessionHelper.getPrincipal();
	var ArrayList = Java.type('java.util.ArrayList');
	var list = new ArrayList();
    var itemList = Collections.list(WorkflowHelper.service.getWorkItems(currentUser));
	
	for(var i = 0; i < itemList.size(); i++) {
		
		var wi = Java.type('wt.workflow.work.WorkItem');
		wi=itemList[i];
		string=wi.getPrimaryBusinessObject().getObject().toString();
	
		if(string.contains("wt.maturity.PromotionNotice"))
		{
			list.add(wi);
		}
	}
    return list;
}


function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var sysOut = Java.type('java.lang.System');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var ComplexValue = Java.type('org.apache.olingo.commons.api.data.ComplexValue');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ArrayList = Java.type('java.util.ArrayList');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
	var owner= Java.type('wt.ownership.Ownership');
	var containerName =Java.type('java.lang.String');
	var state =Java.type('java.lang.String');
	var temp = Java.type('java.lang.String');
	var workItemstatus = Java.type('java.lang.String');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var Class = Java.type('java.lang.Class');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
	var promotionNotice = Java.type('wt.maturity.PromotionNotice');
	var promotionNoticeNumber =Java.type('java.lang.String');
	var promotionNoticeName =Java.type('java.lang.String');
	var subject =Java.type('java.lang.String');
	var role = Java.type('java.lang.String');
	var currentUser = SessionHelper.getPrincipal();
    var currentUserReference = WTPrincipalReference.newWTPrincipalReference(currentUser);
    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
	sysOut.out.println("Entities Method objects  :- "+objects);
    var persistableObjects = OidHelper.getWTCollection(objects);
	
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
	  var listTemp = new ArrayList();
	
    for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
		var persistable = Java.type('wt.fc.Persistable');
        var workItem = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
		
		
		persistable=workItem.getPrimaryBusinessObject().getObject();
		promotionNotice=persistable;
		state=promotionNotice.getState().toString();
		promotionNoticeNumber= promotionNotice.getNumber();
		promotionNoticeName= promotionNotice.getName();
		containerName= promotionNotice.getContainerName();
		owner = workItem.getOwnership();
		workItemstatus=workItem.getStatus().toString();
		role=workItem.getRole().toString();
		var createtimestamp =workItem.getCreateTimestamp();
		subject="Promotion Request -" + promotionNoticeNumber +','+promotionNoticeName;
		temp =workItem.toString();
		var tokenizer = Java.type('java.util.StringTokenizer');
		var taskNumber = Java.type('java.lang.String');
		tokenizer = new tokenizer(temp, ":");
				     while (tokenizer.hasMoreTokens()){
						
				    listTemp.add(tokenizer.nextToken());
					
				     }
		 taskNumber= listTemp.get(1);
        var assignments = PersistenceHelper.manager.navigate(workItem, 'theWfAssignment', Class.forName('wt.workflow.work.WorkItemLink'), true);
        var wfAssignment = assignments.nextElement();
        var assignedTo = owner.getOwner().getName();
        var activities = PersistenceHelper.manager.navigate(wfAssignment, 'activity', Class.forName('wt.workflow.work.ActivityAssignmentLink'), true);
        var activity = activities.nextElement();
        var deadline = activity.getDeadline();
        var name = activity.getName();
        var instructions = activity.getInstructions();
		

        e.addProperty(new Property('Edm.String', 'Name', ValueType.PRIMITIVE, name));
        e.addProperty(new Property('Edm.String', 'Instructions', ValueType.PRIMITIVE, instructions));
        e.addProperty(new Property('Edm.String', 'AssignedTo', ValueType.PRIMITIVE, assignedTo));
        e.addProperty(new Property('Edm.DateTimeOffset', 'Deadline', ValueType.PRIMITIVE, deadline));
		e.addProperty(new Property('Edm.String', 'State', ValueType.PRIMITIVE, state));
		e.addProperty(new Property('Edm.String', 'PromotionNoticeNumber', ValueType.PRIMITIVE, promotionNoticeNumber));
		e.addProperty(new Property('Edm.String', 'Context', ValueType.PRIMITIVE, containerName));
		e.addProperty(new Property('Edm.String', 'WorkItemSubject', ValueType.PRIMITIVE, subject));
		e.addProperty(new Property('Edm.String', 'TaskNumber', ValueType.PRIMITIVE, taskNumber));
		e.addProperty(new Property('Edm.String', 'Status', ValueType.PRIMITIVE, workItemstatus));
		e.addProperty(new Property('Edm.String', 'Role', ValueType.PRIMITIVE, role));
		e.addProperty(new Property('Edm.String', 'Assigned', ValueType.PRIMITIVE, createtimestamp));
        objectEntityMap.put(workItem, e);
		listTemp.clear();
    }

    return objectEntityMap;
}