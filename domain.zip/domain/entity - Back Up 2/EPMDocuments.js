function action_uploadStage1Action(data, params) {
    // call method in ContentHolderEntityDelegate
    var ContentHolderEntityDelegate = Java.type("com.ptc.odata.windchill.entity.service.ContentHolderEntityDelegate");
    return ContentHolderEntityDelegate.uploadStage1Action("document", data, params);
}

function action_uploadStage3Action(data, params) {
    // call method in ContentHolderEntityDelegate
    var ContentHolderEntityDelegate = Java.type("com.ptc.odata.windchill.entity.service.ContentHolderEntityDelegate");
    return ContentHolderEntityDelegate.uploadStage3Action("document", data, params);
}
