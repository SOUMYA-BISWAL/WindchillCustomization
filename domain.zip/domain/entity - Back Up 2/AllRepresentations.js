/**
 * Gets a set of related Entities for a given entity using navigation criteria.
 * @param navigationData
 * @returns Entity Collection of related (linked to) Entities
 */
function getRelatedEntityCollection(navigationData) {
    var HashMap = Java.type('java.util.HashMap');
    var HashSet = Java.type('java.util.HashSet');
    var ArrayList = Java.type('java.util.ArrayList');
	var sysOut=Java.type('java.lang.System');
    var WTPart = Java.type('wt.part.WTPart');
    var ObjectReference = Java.type('wt.fc.ObjectReference');
    var Collections = Java.type('java.util.Collections');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
    var WTHashSet = Java.type('wt.fc.collections.WTHashSet');
    var VersionControlHelper = Java.type("wt.vc.VersionControlHelper");
	var map = new HashMap();
    var targetName = navigationData.getTargetSetName();
	var annotationsList=new ArrayList();
	
	var sourceObjectsList = new WTArrayList(navigationData.getSourceObjects());
	
	if ("AnnotationDetails".equals(targetName)) { 
	
		for(var i = 0; i < sourceObjectsList.size(); i++) {
            var sourceObject = sourceObjectsList.getPersistable(i);
			sysOut.out.println("###############DEWANK################### Source Objects "+sourceObject);
			
			var annotations  = ViewMarkUpHelper.service.getMarkUps(sourceObject);
	
			while(annotations.hasMoreElements()){
				
				annotationsList.add(annotations.nextElement());
			
				}
			
			sysOut.out.println("###############DEWANK################### RepresentationList "+annotationsList);
			map.put(sourceObject, annotationsList);
			sysOut.out.println("###############DEWANK################### Map -> "+ map);
		}
		
    }
	return map;
	
}

function isValidNavigation(navName, sourceObject, targetObjectId, processorData) {
    var WTPart = Java.type('wt.part.WTPart');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WTPartUsageLink = Java.type('wt.part.WTPartUsageLink');
    var WTPartDescribeLink = Java.type('wt.part.WTPartDescribeLink');
    var WTPartReferenceLink = Java.type('wt.part.WTPartReferenceLink');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');   
    var ObjectReference = Java.type('wt.fc.ObjectReference');

    if ("AnnotationDetails".equals(navName)) {

		// All tests passed
        return true;
    } 
	
	// must return null if navigation is not ours
    return null;
}