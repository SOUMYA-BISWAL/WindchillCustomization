function getRelatedEntityCollection(navProcessorData) {
    // Prototype code
    var HashMap = Java.type('java.util.HashMap');
    var ArrayList = Java.type('java.util.ArrayList');
    var Class = Java.type('java.lang.Class');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
    var targetName = navProcessorData.getTargetSetName();
    var map = new HashMap();
    var sourceItems = new WTArrayList(navProcessorData.getSourceObjects());
		var sysout=Java.type('java.lang.System');
    if("promotionWorkitems".equals(targetName)) {
	 var Collections = Java.type('java.util.Collections');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');
	var workitemsss= Java.type('wt.workflow.work.WorkItem');
    var currentUser = SessionHelper.getPrincipal();
	
    var itemList = Collections.list(WorkflowHelper.service.getWorkItems(currentUser));
	sysout.out.println("itemlist size #"+itemlist.size()+"source items ## "+sourceItems.size());
	 for(var i = 0; i < itemList.size(); i++) {
		 
		 
		 
	 }
    
    }
       return map;
}