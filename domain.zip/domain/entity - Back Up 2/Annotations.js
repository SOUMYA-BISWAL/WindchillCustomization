function toEntities(objects, processorData) {
    
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
	var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
	var HashMap = Java.type('java.util.HashMap');
	var Property = Java.type('org.apache.olingo.commons.api.data.Property');
	var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
	var objectEntityMap = new HashMap();
	var Enumeration= Java.type("java.util.Enumeration");
	var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
	var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var sysOut=Java.type('java.lang.System');
	var refFact= Java.type('wt.fc.ReferenceFactory');
	var Collections = Java.type('java.util.Collections');
	var RfObject=Java.type('wt.fc.WTReference');
	var arrayList = Java.type('java.util.ArrayList');
	var VisualizationHelper=Java.type('com.ptc.wvs.common.ui.VisualizationHelper');
	var WTMarkUp=Java.type('wt.viewmarkup.WTMarkUp');
	var Viewable=Java.type('wt.viewmarkup.Viewable');
	var ViewMarkUpHelper=Java.type('wt.viewmarkup.ViewMarkUpHelper');
	var WTException=Java.type('wt.util.WTException');
	var Representation=Java.type('wt.representation.Representation');
	var QueryResult=Java.type('wt.fc.QueryResult');
	var ContentHelper=Java.type('wt.content.ContentHelper');
	var repList=new arrayList();
	var markUpMap=new HashMap();
	
	sysOut.out.println("Entities Method objects class  :- "+objects.getClass());
	sysOut.out.println("Entities Method objects  :- "+objects);
	sysOut.out.println("Processor Data Class :- "+processorData.getClass());
	
	
	var persistableObjects = OidHelper.getWTCollection(objects);
	
	sysOut.out.println("Entities Method persistableObjects  :- "+persistableObjects);
	
	var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
	var list = entityCollection.getEntities();
	sysOut.out.println("Entities Method List  :- "+list);
				
	for each(var e in list)
	//while (markUps.hasMoreElements())
		{
			var markUpEntityId = EntityIDUtils.getInstance().getEntityId(e);
			sysOut.out.println("########## Mark Up Entity Type Class #############"+e.getClass());
			
			var markUpNmId = NmOid.newNmOid(markUpEntityId);
			var markUpobjId = markUpNmId.getOidObject();
			var rfObjectMarkUp = new refFact().getReference(markUpEntityId);
			//System.out.println("Thumbnail URl: "+ContentHelper.service.getDownloadURL(rep,ContentHelper.service.getThumbnail(rep)));
			
			sysOut.out.println("########"+"RefObject is "+rfObjectMarkUp.getObject());
			sysOut.out.println("##########  Start Mark up #############");
					
					
			var localWTMarkUp = rfObjectMarkUp.getObject();
			var copyForward = localWTMarkUp.isAllowCopyForward()?"Enabled":"Disabled";
			var details = "Type: "+localWTMarkUp.getMarkUpType()+", Owner: "+localWTMarkUp.getOwnership().getOwner().getFullName()+", CopyForward: "+copyForward;
			sysOut.out.println("####Locked by#####"+localWTMarkUp.getLockerFullName());
			sysOut.out.println("####Owner#####"+localWTMarkUp.getOwnership().getOwner().getFullName());
			sysOut.out.println("getType "+localWTMarkUp.getMarkUpType()+"\t isAllowCopyForward "+localWTMarkUp.isAllowCopyForward()+"\t getName "+localWTMarkUp.getName());
			
			e.addProperty(new Property('Edm.String', 'AnnotationName', ValueType.PRIMITIVE, localWTMarkUp.getName()));
			e.addProperty(new Property('Edm.String', 'Description', ValueType.PRIMITIVE, localWTMarkUp.getDescription()));
			e.addProperty(new Property('Edm.String', 'LockedBy', ValueType.PRIMITIVE, localWTMarkUp.getLockerFullName()));
			e.addProperty(new Property('Edm.String', 'Type', ValueType.PRIMITIVE, localWTMarkUp.getMarkUpType()));
			e.addProperty(new Property('Edm.String', 'Details', ValueType.PRIMITIVE, details));
			e.addProperty(new Property('Edm.String', 'Owner', ValueType.PRIMITIVE, localWTMarkUp.getOwnership().getOwner().getFullName()));
			e.addProperty(new Property('Edm.String', 'CopyForward', ValueType.PRIMITIVE, localWTMarkUp.isAllowCopyForward()?"Enabled":"Disabled"));
			
			sysOut.out.println("##########  End Mark up #############");
					
			markUpMap.put(localWTMarkUp, e);
		      
		}
	
	sysOut.out.println("####  MAP #### => "+markUpMap);
	 
	return markUpMap;
}

function function_EnableCopyForward(data, params) {
    // Prototype code
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var Vector = Java.type('java.util.Vector');
	var sysOut=Java.type('java.lang.System');
	
	
    var boundWorkItem = params.get('WorkItem').getValue();
	alert(JSON.stringify(boundWorkItem));
    var workItem = data.getProcessor().toObject(boundWorkItem, data);
    var wfAssignedActivity = workItem.getSource().getObject();
    var vec = wfAssignedActivity.getUserEventList().toVector();
    var routes = new Property('Edm.String', 'Routes', ValueType.COLLECTION_PRIMITIVE, vec);
    return routes;
}

function function_DisableCopyForward(data, params) {
    // Prototype code
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var Vector = Java.type('java.util.Vector');

    var boundWorkItem = params.get('WorkItem').getValue();
	alert(JSON.stringify(boundWorkItem));
    var workItem = data.getProcessor().toObject(boundWorkItem, data);
    var wfAssignedActivity = workItem.getSource().getObject();
    var vec = wfAssignedActivity.getUserEventList().toVector();
    var routes = new Property('Edm.String', 'Routes', ValueType.COLLECTION_PRIMITIVE, vec);
    return routes;
}
