function toEntities(objects, processorData) {
    // Prototype code
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');

    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
    var persistableObjects = OidHelper.getWTCollection(objects);
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
    for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
        var changeRequest = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
        var subject = 'Change Request - ' + changeRequest.getNumber() + ', ' + changeRequest.getName();
        e.addProperty(new Property('Edm.String', 'Subject', ValueType.PRIMITIVE, subject));
        objectEntityMap.put(changeRequest, e);
    }
    return objectEntityMap;
}

function getRelatedEntityCollection(navProcessorData) {
    // Prototype code
    var HashMap = Java.type('java.util.HashMap');
    var ArrayList = Java.type('java.util.ArrayList');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
    var ChangeHelper2 = Java.type('wt.change2.ChangeHelper2');
    var targetName = navProcessorData.getTargetSetName();
    var map = new HashMap();
    var sourceChangeRequests = new WTArrayList(navProcessorData.getSourceObjects());
    if("Notices".equals(targetName)) {
        for(var i = 0; i < sourceChangeRequests.size(); i++) {
            var sourceChangeRequest = sourceChangeRequests.getPersistable(i);
            var changeNotices = ChangeHelper2.service.getChangeOrders(sourceChangeRequest, true);
            var list = new ArrayList();
            while(changeNotices.hasMoreElements()) {
                list.add(changeNotices.nextElement());
            }
            map.put(sourceChangeRequest, list);
        }
    }
    if("AffectedItems".equals(targetName)) {
        for(var i = 0; i < sourceChangeRequests.size(); i++) {
            var sourceChangeRequest = sourceChangeRequests.getPersistable(i);
            var changeableItems = ChangeHelper2.service.getChangeables(sourceChangeRequest, true);
            var list = new ArrayList();
            while(changeableItems.hasMoreElements()) {
                list.add(changeableItems.nextElement());
            }
            map.put(sourceChangeRequest, list);
        }
    }
    return map;
}
