function function_GetCostlyParts(data, params) {
var ArrayList = Java.type('java.util.ArrayList');
var EntityCollection = Java.type('org.apache.olingo.commons.api.data.EntityCollection');
var parts = data.getProcessor().readEntitySetData(data);
var partEntityMap = data.getProcessor().toEntities(parts, data);
var partEntities = new ArrayList(partEntityMap.values());
var entityCollection = new EntityCollection();
for(var i = 0; i < partEntities.size(); i++) {
var partEntity = partEntities.get(i);
var partCostProperty = partEntity.getProperty('DevelopmentCost');
if(partCostProperty) {
var partCost = partCostProperty.getValue();
if(partCost && partCost > 0.10) {
entityCollection.getEntities().add(partEntity);
}
}
}return entityCollection;
}