function readEntitySetData(processorData) {
    // Prototype code
    var Collections = Java.type('java.util.Collections');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');

    var currentUser = SessionHelper.getPrincipal();
    var itemList = Collections.list(WorkflowHelper.service.getWorkItems(currentUser));
    return itemList;
}

function toEntities(objects, processorData) {
    // Prototype code
    var OidHelper = Java.type('com.ptc.core.components.util.OidHelper');
    var EntityAttributeProcessor = Java.type('com.ptc.odata.windchill.entity.processor.EntityAttributeProcessor');
    var NmOid = Java.type('com.ptc.netmarkets.model.NmOid');
    var EntityIDUtils = Java.type('com.ptc.odata.core.entity.processor.EntityIDUtils');
    var HashMap = Java.type('java.util.HashMap');
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var ComplexValue = Java.type('org.apache.olingo.commons.api.data.ComplexValue');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var ArrayList = Java.type('java.util.ArrayList');
    var ReferenceFactory = Java.type('wt.fc.ReferenceFactory');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var Class = Java.type('java.lang.Class');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');

    var currentUser = SessionHelper.getPrincipal();
    var currentUserReference = WTPrincipalReference.newWTPrincipalReference(currentUser);
    var refFactory = new ReferenceFactory();
    var objectEntityMap = new HashMap();
    var persistableObjects = OidHelper.getWTCollection(objects);
    var entityCollection = EntityAttributeProcessor.newInstance().createEntities(persistableObjects.persistableCollection(), processorData);
    var list = entityCollection.getEntities();
    for each(var e in list) {
        var entityId = EntityIDUtils.getInstance().getEntityId(e);
        var nmId = NmOid.newNmOid(entityId);
        var objId = nmId.getOidObject();
        var workItem = persistableObjects.getPersistable(persistableObjects.indexOf(objId));
        var assignments = PersistenceHelper.manager.navigate(workItem, 'theWfAssignment', Class.forName('wt.workflow.work.WorkItemLink'), true);
        var wfAssignment = assignments.nextElement();
        var assignedTo = null;
        var principals = wfAssignment.getPrincipals();
        if (principals !== undefined && principals.contains(currentUserReference)) {
            assignedTo = currentUser.getAuthenticationName();
        }
        var activities = PersistenceHelper.manager.navigate(wfAssignment, 'activity', Class.forName('wt.workflow.work.ActivityAssignmentLink'), true);
        var activity = activities.nextElement();
        var deadline = activity.getDeadline();
        var name = activity.getName();
        var instructions = activity.getInstructions();

        e.addProperty(new Property('Edm.String', 'Name', ValueType.PRIMITIVE, name));
        e.addProperty(new Property('Edm.String', 'Instructions', ValueType.PRIMITIVE, instructions));
        e.addProperty(new Property('Edm.String', 'AssignedTo', ValueType.PRIMITIVE, assignedTo));
        e.addProperty(new Property('Edm.DateTimeOffset', 'Deadline', ValueType.PRIMITIVE, deadline));

        objectEntityMap.put(workItem, e);
    }
    return objectEntityMap;
}

function getRelatedEntityCollection(navProcessorData) {
    // Prototype code
    var HashMap = Java.type('java.util.HashMap');
    var ArrayList = Java.type('java.util.ArrayList');
    var Class = Java.type('java.lang.Class');
    var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
    var targetName = navProcessorData.getTargetSetName();
    var map = new HashMap();
    var sourceItems = new WTArrayList(navProcessorData.getSourceObjects());
    if("PrimaryBusinessObject".equals(targetName)) {
        for(var i = 0; i < sourceItems.size(); i++) {
            var sourceItem = sourceItems.getPersistable(i);
            var primaryBusinessObject = sourceItem.getPrimaryBusinessObject().getObject();
            var list = new ArrayList();
            list.add(primaryBusinessObject);
            map.put(sourceItem, list);
        }
    }
    if("Assignee".equals(targetName)) {
        var currentPrincipal = SessionHelper.getPrincipal();
        var currentPrincipalReference = WTPrincipalReference.newWTPrincipalReference(currentPrincipal);
        for(var i = 0; i < sourceItems.size(); i++) {
            var sourceItem = sourceItems.getPersistable(i);
            var assignments = PersistenceHelper.manager.navigate(sourceItem, 'theWfAssignment', Class.forName('wt.workflow.work.WorkItemLink'), true);
            var wfAssignment = assignments.nextElement();
            var list = new ArrayList();
            var principals = wfAssignment.getPrincipals();
            if(principals != undefined && principals.contains(currentPrincipalReference)) {
                var assignee = currentPrincipal;
                list.add(assignee);
            }
            map.put(sourceItem, list);
        }
    }
    return map;
}


function action_CompleteTask(data, params) {
    // Prototype code
    var Vector = Java.type('java.util.Vector');
    var ActionResult = Java.type('com.ptc.odata.core.entity.processor.ActionResult');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
    var SessionHelper = Java.type('wt.session.SessionHelper');

    var boundWorkItem = params.get('WorkItem').getValue();
    var workItem = data.getProcessor().toObject(boundWorkItem, data);

    var currentUser = SessionHelper.getPrincipal();
    var principalRef = WTPrincipalReference.newWTPrincipalReference(currentUser);

    var eventList = params.get('Routes').getValue();
    var routeVector = new Vector();
    for(var i = 0; i < eventList.length; i++) {
        routeVector.add(eventList[i]);
    }

    WorkflowHelper.service.workComplete(workItem, principalRef, routeVector);

    workItem = PersistenceHelper.manager.refresh(workItem);
    var workItemEntity = data.getProcessor().toEntity(workItem, data);

    var result = new ActionResult();
    result.setReturnedObject(workItemEntity);
    return result;
}

function action_Comment(data, params) {
    // Prototype code
    // Following code does not use supported APIs and cannot be used in
    //  customer deployments
    var Vector = Java.type('java.util.Vector');
    var ActionResult = Java.type('com.ptc.odata.core.entity.processor.ActionResult');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
    var SessionHelper = Java.type('wt.session.SessionHelper');

    var boundWorkItem = params.get('WorkItem').getValue();
    var workItem = data.getProcessor().toObject(boundWorkItem, data);

    var comments = params.get('Comments').getValue();
    var processData = workItem.getContext();
    if (processData === undefined || processData === null) {
        var activity = workItem.getSource().getObject();
        processData = activity.getContext().copy();
    }
    processData.setTaskComments(comments);
    workItem.setContext(processData);
    workItem = PersistenceHelper.manager.save(workItem);

    var workItemEntity = data.getProcessor().toEntity(workItem, data);

    var result = new ActionResult();
    result.setReturnedObject(workItemEntity);
    return result;
}

function action_SetVariable (data, params) {
    // Prototype code
    // Following code does not use supported APIs and cannot be used in
    //  customer deployments
    var Vector = Java.type('java.util.Vector');
    var ActionResult = Java.type('com.ptc.odata.core.entity.processor.ActionResult');
    var PersistenceHelper = Java.type('wt.fc.PersistenceHelper');
    var WorkflowHelper = Java.type('wt.workflow.work.WorkflowHelper');
    var WTPrincipalReference = Java.type('wt.org.WTPrincipalReference');
    var SessionHelper = Java.type('wt.session.SessionHelper');
    var WfEngineServerHelper = Java.type('wt.workflow.engine.WfEngineServerHelper');
    var Transaction = Java.type('wt.pom.Transaction');

    var boundWorkItem = params.get('WorkItem').getValue();
    var workItem = data.getProcessor().toObject(boundWorkItem, data);
    var activity = workItem.getSource().getObject();

    var varName = params.get('Name').getValue();
    var varValue = params.get('Value').getValue();

    var processData = workItem.getContext();
    if (processData === undefined || processData === null) {
        processData = activity.getContext();
    }

    var oldProcessData = processData.copy();
    processData.setValue(varName, varValue);

    var trx = new Transaction();
    trx.start();

    activity = PersistenceHelper.manager.lockAndRefresh(activity);
    activity.setContext(processData);
    activity = PersistenceHelper.manager.save(activity);
    WfEngineServerHelper.service.changeDataEvent(activity, oldProcessData);

    workItem = PersistenceHelper.manager.lockAndRefresh(workItem);
    workItem.setContext(processData);
    workItem = PersistenceHelper.manager.save(workItem);

    trx.commit();
    trx = null;

    var workItemEntity = data.getProcessor().toEntity(workItem, data);

    var result = new ActionResult();
    result.setReturnedObject(workItemEntity);
    return result;
}

function function_GetRoutes(data, params) {
    // Prototype code
    var ValueType = Java.type('org.apache.olingo.commons.api.data.ValueType');
    var Property = Java.type('org.apache.olingo.commons.api.data.Property');
    var Vector = Java.type('java.util.Vector');

    var boundWorkItem = params.get('WorkItem').getValue();
    var workItem = data.getProcessor().toObject(boundWorkItem, data);
    var wfAssignedActivity = workItem.getSource().getObject();
    var vec = wfAssignedActivity.getUserEventList().toVector();
    var routes = new Property('Edm.String', 'Routes', ValueType.COLLECTION_PRIMITIVE, vec);
    return routes;
}
