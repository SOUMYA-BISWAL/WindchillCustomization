function getRelatedEntityCollection(navProcessorData) {
	// Prototype code
	var HashMap = Java.type('java.util.HashMap');
	var ArrayList = Java.type('java.util.ArrayList');
	var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var ChangeHelper2 = Java.type('wt.change2.ChangeHelper2');
	var targetName = navProcessorData.getTargetSetName();
	var map = new HashMap();
	var sourceChangeTasks = new WTArrayList(navProcessorData.getSourceObjects());
	if("AffectedItems".equals(targetName)) {
		for(var i = 0; i < sourceChangeTasks.size(); i++) {
			var sourceChangeTask = sourceChangeTasks.getPersistable(i);
			var affectedItems = ChangeHelper2.service.getChangeablesBefore(sourceChangeTask, true);
			var list = new ArrayList();
			while(affectedItems.hasMoreElements()) {
				list.add(affectedItems.nextElement());
			}
			map.put(sourceChangeTask, list);
		}
	} else if("ResultingItems".equals(targetName)) {
		for(var i = 0; i < sourceChangeTasks.size(); i++) {
			var sourceChangeTask = sourceChangeTasks.getPersistable(i);
			var resultingItems = ChangeHelper2.service.getChangeablesAfter(sourceChangeTask, true);
			var list = new ArrayList();
			while(resultingItems.hasMoreElements()) {
				list.add(resultingItems.nextElement());
			}
			map.put(sourceChangeTask, list);
		}
	}
	return map;
}
