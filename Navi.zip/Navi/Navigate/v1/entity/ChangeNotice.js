function getRelatedEntityCollection(navProcessorData) {
	// Prototype code
	var HashMap = Java.type('java.util.HashMap');
	var ArrayList = Java.type('java.util.ArrayList');
	var WTArrayList = Java.type('wt.fc.collections.WTArrayList');
	var ChangeHelper2 = Java.type('wt.change2.ChangeHelper2');
	var targetName = navProcessorData.getTargetSetName();
	var map = new HashMap();
	var sourceChangeNotices = new WTArrayList(navProcessorData.getSourceObjects());
	if("Tasks".equals(targetName)) {
		for(var i = 0; i < sourceChangeNotices.size(); i++) {
			var sourceChangeNotice = sourceChangeNotices.getPersistable(i);
			var changeTasks = ChangeHelper2.service.getChangeActivities(sourceChangeNotice, true);
			var list = new ArrayList();
			while(changeTasks.hasMoreElements()) {
				list.add(changeTasks.nextElement());
			}
			map.put(sourceChangeNotice, list);
		}
	}
	return map;
}
