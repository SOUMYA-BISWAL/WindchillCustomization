package ext.otis.custom;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import wt.util.WTProperties;
 
/**
 * 
 * @author Soumya Ranjan Biswal
 * 		   Siddharth Sinha
 *
 */

public class FileUpload extends HttpServlet {
	 
	   
	/**
	 * @Override
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 * 
	 */
	
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	WTProperties wtProperties = WTProperties.getLocalProperties();
        String wtHome = wtProperties.getProperty("wt.home");
        String uploadFileDirectory = wtHome+File.separator+"temp"+File.separator+"mof";
        String returnStatusMessage = null;
       
	   String fileName = StringUtils.EMPTY;
	   
        //check if its multipart content
        if(ServletFileUpload.isMultipartContent(request)){
            try {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
               
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()).getName();
                        item.write( new File(uploadFileDirectory + File.separator + name));
						fileName = uploadFileDirectory+File.separator+name;
                    }
                }
                System.out.println(fileName);
                //send uploaded file to XLReader Class
                XLReader xlReader = new XLReader();
                returnStatusMessage = xlReader.readXLCellValue(fileName);
                
                String[] output  = returnStatusMessage.split(",");
                
               //File uploaded successfully
                PrintWriter out = response.getWriter();
                out.println("<html>");
    			out.println("<body>");
    			for (String outputStr : output){
    			out.println("<h4> "+outputStr+" </h4>");
    			}
    			out.println("</body>");
    			out.println("</html>");
    			
    			
               request.setAttribute("message", "File Uploaded Successfully");
			   request.setAttribute("fileName", fileName);
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
            }          
          
        }else{
            request.setAttribute("message",
                                 "Sorry this Servlet only handles file upload request");
        }
     
      
    }
   
}