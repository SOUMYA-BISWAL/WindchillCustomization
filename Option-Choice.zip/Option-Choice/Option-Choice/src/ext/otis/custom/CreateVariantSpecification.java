package ext.otis.custom;

import java.util.ArrayList;
import java.util.List;

import com.ptc.windchill.option.bean.VariantLoadATORuleConfigSpecBean;
import com.ptc.windchill.option.bean.VariantLoadNavCriteriaBean;
import com.ptc.windchill.option.bean.VariantLoadPartConfigSpecBean;
import com.ptc.windchill.option.variantspec.loader.VariantSpecLoaderHelper;

import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainerRef;
import wt.part.WTPart;

/**
 * 
 * @author Soumya Ranjan Biswal
 * 		   Siddharth Sinha
 *
 */

public class CreateVariantSpecification {
	
	/**
	 * This method for creating VariantSpecification based on WTPart,Option and Choice
	 * @param part
	 * @param optionValue
	 * @param choiceValue
	 * @return returnStatusMessage
	 */
	
	public String createVariant(WTPart part , String optionValue , String choiceValue) {
		
		String returnStatusMessage = null;
		
		try {
			System.out.println("CreateVariant Method Start");
			String partConfigFilter = part.getName().toString()+"_PartConfig";
			String aTOConfigFilter = part.getName().toString()+"_ATOConfigSpec";
			String variantSpecName = part.getName().toString()+"_VS";
			WTContainerRef myPartContainerReference = null;
			Folder folder = null;
			VariantLoadNavCriteriaBean criteriaBean = null;
			
			//Conatiner
			myPartContainerReference = part.getContainerReference();
			folder = FolderHelper.service.getFolder("/Default",myPartContainerReference);
	        System.out.println(folder.getFolderPath());
	        System.out.println(folder.getContainerName());
	        
	        // Create part config specs
	        List<VariantLoadPartConfigSpecBean> partConfigSpecBeans = new ArrayList<VariantLoadPartConfigSpecBean> (1);
	        VariantLoadPartConfigSpecBean partConfigSpecBean1 = new VariantLoadPartConfigSpecBean(partConfigFilter, null, null, null, null);
	        partConfigSpecBeans.add(partConfigSpecBean1);
	        
            // Create a Latest ATO rule Config spec
            List<VariantLoadATORuleConfigSpecBean> atoConfigSpecBeans = new ArrayList<VariantLoadATORuleConfigSpecBean> (1);
            VariantLoadATORuleConfigSpecBean atoConfigSpecBean1 = new 
            VariantLoadATORuleConfigSpecBean(aTOConfigFilter, null, null);
            atoConfigSpecBeans.add(atoConfigSpecBean1);
            
            
            // Create a Variant spec
            criteriaBean = new VariantLoadNavCriteriaBean();
            criteriaBean.setVariantSpecName(variantSpecName);
            criteriaBean.setVariantSpecDescription(variantSpecName);
            criteriaBean.setVariantSpecFolder(folder.getFolderPath());
            criteriaBean.setVariantSpecCreateVariants(false);
            criteriaBean.setPartNumber(part.getNumber());
            criteriaBean.setRuleCheckingDisabled(true);
           
            //Create a Option and choices list
            List<String> choices = new ArrayList<String>();
            choices.add(choiceValue);
            criteriaBean.addChoiceNames(optionValue, choices);
            
            
            // Use the part and option filter config specs from above
            criteriaBean.addPartConfigSpec(partConfigFilter);
            criteriaBean.addAtoRuleConfigSpecs(aTOConfigFilter);
            
            List<VariantLoadNavCriteriaBean> criteriaBeansList = new ArrayList<VariantLoadNavCriteriaBean>(1);
            criteriaBeansList.add(criteriaBean);
            
            //Store in windchill database 
            VariantSpecLoaderHelper.service.loadVariantSpecs(criteriaBeansList, partConfigSpecBeans, atoConfigSpecBeans);
			
            returnStatusMessage = "MOF File uploaded successfully";
			
		} catch (Exception e) {
			e.printStackTrace();	
		}
		return returnStatusMessage;
	}

}
