package ext.otis.custom;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 * @author Soumya Ranjan Biswal
 * 		   Siddharth Sinha
 * 
 *
 */

public class XLReader {

	/**
	 * Variable declaration
	 */
	
	private static FileInputStream xlsxFile = null;
	private static XSSFWorkbook workbook = null;
	private static XSSFSheet sheet = null;
	private static Row row = null;
	private static String property = "";
	private static String value = "";
	private static Map<String,String> propertyValuePair=new HashMap<String,String>(); 
	
	/**
	 * readXLCellValue method is reading options and choices value in excel sheet 
	 * @SuppressWarnings("deprecation")
	 * @param uploadFile
	 * @throws Exception
	 * @return returnStatusMessage
	 */
	
	@SuppressWarnings("deprecation")
	public String readXLCellValue(String uploadFile) throws Exception{
		propertyValuePair.clear();
		System.out.println("File Path ################ :"+uploadFile);
		String returnStatusMessage = "";
		File xlFilePath  = new File(uploadFile);
		xlsxFile = new FileInputStream(xlFilePath);
		workbook = new XSSFWorkbook(xlsxFile);
		sheet = workbook.getSheetAt(1);
		String propertyHeader = null;
		String valueHeader = null;
		
		int startRowIndex = 0;
		for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
	            row = sheet.getRow(rowIndex);
	            Cell propertyHeaderCell = row.getCell(7);
	            if(null == propertyHeaderCell) {
	            	continue;
	            }else {
	            	if (propertyHeaderCell.getCellType() == 1){
			        	propertyHeader = propertyHeaderCell.getStringCellValue();
			        }else if(propertyHeaderCell.getCellType() == 0){
			        	propertyHeader = ""+propertyHeaderCell.getNumericCellValue();
			        }
	            }
	            
	            Cell valueHeaderCell = row.getCell(11);
	            if(null == valueHeaderCell) {
	            	continue;
	            }else {
	            	if(valueHeaderCell.getCellType() == 0) {
			        	valueHeader = ""+valueHeaderCell.getNumericCellValue();
			        }else {
			        	valueHeader = valueHeaderCell.getStringCellValue();
			        }
	            }
	            if(valueHeader.equals("Value") && propertyHeader.equals("Property") ) {
	            	startRowIndex =rowIndex+1;
	            	break;
	            }
	        }
		

	    for (int rowIndex = startRowIndex ; rowIndex <= sheet.getLastRowNum() ; rowIndex++) {
	    	
	    	row = sheet.getRow(rowIndex);
	        Cell propertyCell = row.getCell(7);
	        if(null == propertyCell) {
	        	continue;
	        }else {
	        	if(propertyCell.getCellType() == 0) {
		        	property = ""+propertyCell.getNumericCellValue();
		        }else {
		        	property = propertyCell.getStringCellValue();
		        }
	        }
	        
	        Cell valueCell = row.getCell(11);
	        if(null == valueCell) {
	        	continue;
	        }else {
	        	if(valueCell.getCellType() == 0) {
	 	        	value = ""+valueCell.getNumericCellValue();
	 	        }else {
	 	        	value = valueCell.getStringCellValue();
	 	        }
	        }
	        if(StringUtils.EMPTY != property) {
	        	propertyValuePair.put(property, value);
	        	System.out.println("Here in StringUtils.EMpty "+propertyValuePair);
	        }
	    }
	    
	    StringBuilder str = new StringBuilder(returnStatusMessage);

	    /**
	     * Iteration generated map and send to FetchAssociatedPart for getting associated part and create new variant spec
	     */
		for (Map.Entry<String,String> entry : propertyValuePair.entrySet())  {
			String optionValue = entry.getKey();
			String choiceValue = entry.getValue();
			FetchAssociatedPart associatedPart = new FetchAssociatedPart();
			System.out.println("Option "+optionValue+"Choice "+choiceValue);
			returnStatusMessage = associatedPart.getAssociatedPart(optionValue,choiceValue);
			str.append(returnStatusMessage).append(",");
			
		}
		returnStatusMessage = str.toString();
		System.out.println(returnStatusMessage); 
	    return returnStatusMessage;
	}
}

