package ext.otis.custom;

import com.ptc.windchill.option.model.Choice;
import com.ptc.windchill.option.model.OptionSet;
import com.ptc.windchill.option.service.OptionHelper;
import com.ptc.windchill.option.model.ChoiceMappableChoiceLink;
import com.ptc.windchill.option.model.ChoiceMaster;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
/**
 * 
 * @author Soumya Ranjan Biswal
 * 		   Siddharth Sinha
 * 
 *
 */
public class FetchAssociatedPart {
	
	/**
	 * Below method for fetch AssociatedWTPart based on Options and Choices and calling CreateVariantSpecification
	 * and passing WTPart, Options and Choices after successfull execution it will return success message as String value 
	 * @param optionValue
	 * @param choiceValue
	 * @return returnStatusMessage
	 */
	
	public String getAssociatedPart(String optionValue , String choiceValue) {
			
		OptionSet optionSet = null;
		Choice choice = null;
		WTPart part = null;
		String returnStatusMessage = null;
		try {
			optionSet = fetchOptionSet();
			System.out.println(optionSet.getName());
			choice = fetchOptionChoice(optionValue, choiceValue, optionSet); 
			System.out.println("Choice name: " + choice);
			if(choice == null) { 
				returnStatusMessage = optionValue+" Option and "+choiceValue+" Choices not found ";
				return returnStatusMessage; 
			}else {
				part = fetchWTPartByChoice((ChoiceMaster) choice.getMaster());
				if(part.equals(null)) {
					returnStatusMessage = "Part is not found for "+optionValue+" Option and "+choiceValue+" Choices ";
				}else {
					CreateVariantSpecification createVariantObj = new CreateVariantSpecification();
					returnStatusMessage = createVariantObj.createVariant(part, optionValue, choiceValue);
					System.out.println("Part Number 2: "+part.getNumber());
				}
			}
		} catch (WTException e) {
			System.out.println("No Option Set Found " + e);
		}

		return returnStatusMessage;
	}
		
	/**
	 * Below method for fetch AssociatedWTPart based on Choices 
	 * @param choice
	 * @return
	 * @throws WTException
	 */
	
	public static WTPart fetchWTPartByChoice(ChoiceMaster choice) throws WTException {
		System.out.println("Entering in Method fetchWTPartByChoice ");
		WTPart part = null;
		ChoiceMappableChoiceLink cmlLink = null;
		WTPartUsageLink wtpLink = null;
		QueryResult cmlQueryResult = null;
		QuerySpec cmlQuerySpec = new QuerySpec(ChoiceMappableChoiceLink.class);
		long choiceOidNumber = choice.getPersistInfo().getObjectIdentifier().getId();
		cmlQuerySpec.appendWhere(new SearchCondition(ChoiceMappableChoiceLink.class,"roleBObjectRef.key.id",SearchCondition.EQUAL, choiceOidNumber ),null);
		cmlQueryResult = PersistenceHelper.manager.find((StatementSpec)cmlQuerySpec);
		System.out.println("cmlQueryResult Size : "+cmlQueryResult.size());
		if(cmlQueryResult.size() == 0) {
			part = null;
		}else {
			while(cmlQueryResult.hasMoreElements()) {
				cmlLink = (ChoiceMappableChoiceLink) cmlQueryResult.nextElement();
				System.out.println("cmlLink : "+cmlLink.getRoleAObject().getConceptualClassname());
				if(cmlLink.getRoleAObject() instanceof WTPartUsageLink) {
					wtpLink = (WTPartUsageLink) cmlLink.getRoleAObject();
					System.out.println("wtpLink : "+wtpLink.getComponentId());
				}
			}
			part = (WTPart) wtpLink.getRoleAObject();
			System.out.println("Part Name : "+part.getName());
			QueryResult localQueryResult = WTPartHelper.service.getUsedByWTParts(part.getMaster());
			while(localQueryResult.hasMoreElements()) {
				part = (WTPart) localQueryResult.nextElement();
				System.out.println("Part Number 5: "+part.getNumber());
			}
		}
		return part;
	}

	/**
	 * Below method for fetch OptionSet based
	 * @return optionSet
	 * @throws WTException
	 */
	
	public static OptionSet fetchOptionSet() throws WTException {
		System.out.println("fetchOptionSet ");
		OptionSet optionSet = null;
		QuerySpec qsSet = new QuerySpec(OptionSet.class);
		QueryResult qres = PersistenceHelper.manager.find(qsSet);
		while (qres.hasMoreElements()) {
			optionSet = (OptionSet) qres.nextElement();
		}
		return optionSet;
	}

	/**
	 * Below method for fetch Option and Choice optioName, choiceName and optionSet
	 * @param option
	 * @param choice
	 * @param optionSet
	 * @return
	 * @throws WTException
	 */
	
	public static Choice fetchOptionChoice(String option, String choice, OptionSet optionSet) throws WTException {
		Choice choiceOptn = null;
		try {
			System.out.println(optionSet.getContainerReference());
			choiceOptn = OptionHelper.service.getChoice(choice, option, optionSet.getContainerReference());
			System.out.println("ChoiceName :"+choiceOptn.getName());
		} catch (WTException e) {
			System.out.println("No Option or Choice Found " + e);
		}
		return choiceOptn;

	}

}

